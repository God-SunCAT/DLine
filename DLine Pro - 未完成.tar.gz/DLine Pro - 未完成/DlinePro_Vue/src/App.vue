<script>
let id = 0;
import { reactive, toRefs } from "vue";
import UnknownAvatar from "@/assets/images/UnknownAvatar.png"
import icon_PassCard from "./components/icons/icon_PassCard.vue"
import icon_message from "./components/icons/icon_message.vue"
import icon_public from "./components/icons/icon_public.vue"
import List_Message from "./components/List_Message.vue"
import Chat_Activity from "./components/Chat_Activity.vue"
import icon_back from "./components/icons/icon_back.vue"
import Dynamic_Activity from "./components/Dynamic_Activity.vue"
import Public_Activity from "./components/Public_Activity.vue"
import PassCard_Activity from "./components/PassCard_Activity.vue"
import WCML from "@/assets/images/我出门啦.jpg"
export default{
  created(){
    window['UIEvent'] = (type,data) => {
      this.UIEvent(type,data)
    } //暴露一个方法
    this.PostMessage(0,0)
    this.PostMessage(1,0)
    this.RenderPage = 3

  },
  setup() {
    const state = reactive({});
    return {
      UnknownAvatar
    }
  }, 
  components: {
    icon_PassCard,
    icon_message,
    icon_public,
    icon_back,
    List_Message,
    Chat_Activity,
    Dynamic_Activity,
    Public_Activity,
    PassCard_Activity
  },
  data(){
    return{
      RenderPage: 0,// 1Message_List|2Chat_Activity|3List_PassCard|4List_Public|5Dynamic
      UserInfo:['星辰','最高权限',WCML],// 0 name|1 state|2 avatar
      ChatUserInfo:['Unknown','Introduction','Avatar',0,0,0,''],//Name|Introduction|Avatar|Sex|Push|Online|ID && Push Model -> 0 Push | 1 unPush && Online -> 0 No | 1 Yes
      ChatMessage:[],
      ChatOpinion:[false,"Op1","Op2"],
      DynamicMessage:[],
      // ListData_Message:[],
      // ListData_PassCard:[]

      ListData_Message:[{id: 0,avatar:WCML,name:"Dline - 迈向星辰大海！",introduction:"嘿嘿嘿！",content:'好多年没用这软件应该还好用吧',time:"PM8:20",unread:"3"}],
      ListData_PassCard: [{id:0,title:"迷失森林 - 让.雷扎",info:"迷失在森林中，你找得到路吗",state:0}]
    }
  },
  methods:{
    Click_icon_PassCard(){
      this.PostMessage(1,0)
      if(this.RenderPage != 3){
        this.RenderPage = 3
      }
    },
    Click_icon_message(){
      if(this.RenderPage != 1){
        this.RenderPage = 1
      }
    },
    Click_icon_public(){
      if(this.RenderPage != 4){
        this.RenderPage = 4
      }
    },
    ComEvent(ComID,type,data){
      //id List_Message 1|Chat_Activity 2|
      // 1List_Message|2Chat_Activity|3List_Person|4List_Public|5Dynamic
      if(ComID==0){
        switch (type){
          case 0:
            if(this.RenderPage==2){
              this.ChatMessage = []
              this.RenderPage=1
            }
            else if(this.RenderPage==5){
              this.DynamicMessage = []
              this.RenderPage=2
            }
          break
        }
      }
      else if(ComID==1){
        switch (type){//进入Chat界面 data=id
          case 0://进入Chat界面 data=id
            for(var i=0;i<this.ListData_Message.length;i++){
              if(this.ListData_Message[i].id==data){
                this.ChatMessage = []
                this.ChatUserInfo[0]=this.ListData_Message[i].name
                this.ChatUserInfo[1]=this.ListData_Message[i].introduction
                this.ChatUserInfo[2]=this.ListData_Message[i].avatar
                this.ChatUserInfo[3]=0
                this.ChatUserInfo[4]=0
                this.ChatUserInfo[5]=0
                this.ChatUserInfo[6]=this.ListData_Message[i].id
                this.RenderPage = 2
                break
              }
            }  
          break
          case 1:
            this.RenderPage = 5 //进入动态页面
            break
        }
      }
    },
    UIEvent(type,data){
      switch(type){
        case 0://设置Page页面
          this.RenderPage = data //data 整数
          break
        case 1://设置message列表
          this.ListData_Message = data //data数组
          break
        case 2://设置UserInfo
          this.UserInfo = data //data数组
          break
        case 3://设置ChatUserInfo
          this.ChatUserInfo = data //data数组
          break
        case 4://设置ChatMessage
          this.ChatMessage = data //data数组
          break
        case 5://追加ChatMessage 前追加
          this.ChatMessage.unshift(data) //data数组
          break
        case 6://追加ChatMessage 后追加
          this.ChatMessage.push(data) //data数组
          break
        case 7://设置ChatOpinion
          this.ChatOpinion = data //data数组
          break
        case 8://设置DynamicMessage
          this.DynamicMessage = data //data数组
          break
        case 9://追加DynamicMessage 前追加
          this.DynamicMessage.unshift(data) //data数组
          break
        case 10://设置ListData_PassCard
          this.ListData_PassCard = data
          break
        case 11://追加ListData_PassCard 后追加
          this.ListData_PassCard.push(data)
          break
        case 12://设置用户信息
          this.UserInfo = data
          break
        case 13://刷新ChatActivity列表
          try {
            this.$refs.ChatActivity.RefreshData()
          } catch (error) {}
          break
      }
    },
    GetHeaderTitle(){
      switch(this.RenderPage){
        case 3:
          return(this.$t('lang.PassCard'))
        case 4:
          return(this.$t('lang.public'))
        case 5:
          return(this.$t('lang.dynamic'))
      }
    }
  },
  watch:{
    RenderPage(newID){
      switch(newID){
        // 1List_Message|2Chat_Activity|3List_Person|4List_Public|5Dynamic
        case 1://List_Message
          break
        case 2://Chat_Activity
          break
        case 5://Dynamic
          break
      }
    }
  }
}
</script>
<template>
<div 
  id="Header" 
  :style="{
    height:(this.arif(RenderPage,[2,5],true)?'3rem':'3.5rem')
  }"
>
  <div>
    <!-- 主页头像：不应用于Chat及Dynamic -->
    <img
      v-if="this.arif(RenderPage,[2,5],false)"
      v-viewer
      class="Avatar"
      :src="UserInfo[2]"
      @error="e => { e.target.src = UnknownAvatar }"
    />
    <div
      v-if="RenderPage==1"
      id="User_Info"
    >
      <span id="User_Name">
        {{UserInfo[0]}}
      </span>
      <br />
      <span id="User_State">
        {{UserInfo[1]}}
      </span>
    </div>
    <div
      v-if="this.arif(RenderPage,[1,2],false)" 
      id="HeaderTitle"
    >
    {{GetHeaderTitle()}}
    </div>
    <icon_back
      v-if="this.arif(RenderPage,[2,5],true)"
      @click="ComEvent(0,0,0)"
    />
    <div v-if="RenderPage==2">
      <div class="ChatUserInfo">
        <span id="ChatUser_Name">
          {{ChatUserInfo[0]}}
        </span>
        <br />
        <!-- rgb(206,202,195) 离线 | rgb(62, 114, 252) 在线-->
        <span
          id="ChatUser_State"
          :style="{
            color:ChatUserInfo[5]==0?'rgb(206,202,195)':'rgb(62, 114, 252)'
          }"
        >
          {{ChatUserInfo[5]==0?$t('lang.offline'):$t('lang.online')}}
        </span>
      </div>
      <img
        v-if="RenderPage==2"
        class="ChatAvatar"
        :src="ChatUserInfo[2]"
        @click="ComEvent(1,1,0)"
        @error="e => { e.target.src = UnknownAvatar }"
      >
    </div>
  </div>
</div>
<div 
  id="container" 
  :style="{
    height:(this.arif(RenderPage,[2,5],true)?'calc(100% - 3rem)':'calc(100% - 6.5rem)'),
    top:(this.arif(RenderPage,[2,5],true)?'3rem':'3.5rem')
  }"
>
  <List_Message
    v-show="RenderPage==1"
    :ListData="ListData_Message"
    @ComEvent="ComEvent"
    :UnknownAvatar="UnknownAvatar"
  />
  <Chat_Activity
    v-if="this.arif(RenderPage,[2,5],true)"
    v-show="RenderPage==2"
    ref="ChatActivity"
    :ListData="ChatMessage"
    :ChatUserInfo="ChatUserInfo"
    :Opinion_Info="ChatOpinion"
    @ComEvent="ComEvent"
    :UnknownAvatar="UnknownAvatar"
  />
  <PassCard_Activity 
    v-if="RenderPage==3"
    :UserInfo="UserInfo"
    :UnknownAvatar="UnknownAvatar"
    :ListData="ListData_PassCard"
  />
  <Public_Activity
    v-if="RenderPage==4"
  />
  <Dynamic_Activity
    v-if="RenderPage==5"
    :ListData="DynamicMessage"
    :UserInfo="ChatUserInfo"
    :ChatUserInfo="ChatUserInfo"
    :UnknownAvatar="UnknownAvatar"
  />
</div>
<div
  id="BottomMenu"
  :style="{height:(this.arif(RenderPage,[2,5],true)?'0':'3rem')}"
>
  <icon_PassCard
    @click="Click_icon_PassCard"
    :color="RenderPage==3?'#0066cc':'#999999'"
  />
  <icon_message
    @click="Click_icon_message"
    :color="RenderPage==1?'#0066cc':'#999999'"
  />
  <icon_public
    @click="Click_icon_public"
    :color="RenderPage==4?'#0066cc':'#999999'"
  />
</div>
</template>
<style scoped>
#Header{
  box-sizing: border-box;
  background-color: #1d1d1d;
  height: 3.5rem;
  width: 100%;
  overflow: hidden;
  position: fixed;
  border-bottom: 1px solid #2e2e2e;
  transition: height 0.4s;
}
#container{
  transition: height 0.4s,top 0.4s;
  position: fixed;
  top: 3.5rem;
  width: 100%;
  height: calc(100% - 6.5rem);
  overflow-x: hidden;
  overflow-y: hidden;
}
#BottomMenu{
  box-sizing: border-box;
  border-top: 1px solid #3b3b3ba1;
  position: fixed;
  bottom: 0;
  height: 3rem;
  width: 100%;
  overflow: hidden;
  transition: height 0.4s ease;
}
.Avatar{
  object-fit: cover;
  overflow: auto;
  float: left;
  position: relative;
  top: 0.425em;
  left: 0.5em;
  margin-right: 1em;
  height: 2.65em;
  width: 2.65em;
  border-radius: 50px;
}
.ChatUserInfo{
  position: absolute;
  top: 0.6em;
  line-height: 1em;
  text-align: center;
  width: 100%;
}
.ChatUserInfo span{
  left: 0;
  width: 100%;
  text-align: center;
}
#ChatUser_Name{
  font-weight: 600;
  font-size: 1.03rem;
}
#ChatUser_State{
  font-size: 0.75rem;
}
.ChatAvatar{
  z-index: 1;
  object-fit: cover;
  overflow: auto;
  float: right;
  position: relative;
  top: 0.3em;
  right: 0.5em;
  /* margin-right: 1em; */
  height: 2.4em;
  width: 2.4em;
  border-radius: 50px;
}
#User_Info{
  position: relative;
  top: 0.8em;
  line-height: 1em;
}
#User_Name{
  font-weight: 500;
  font-size: 1rem;
}
#User_State{
  font-size: 0.6em;
}
#HeaderTitle{
  position: fixed;
  top: 0;
  width: 100%;
  height: 3rem;
  font-size: 1.2rem;
  text-align: center;
  line-height: 3rem;
  white-space: nowrap;
}
</style>