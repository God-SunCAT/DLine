import { createApp } from 'vue'
//----
import vueI18n from './i18n'
import 'viewerjs/dist/viewer.css'
import VueViewer from 'v-viewer'

//----
import App from './App.vue'
import './assets/main.css'
//-------------
function GetURL(data){
	var blob = new Blob(data, { type: "image/png" });
	return(URL.createObjectURL(blob))
}
const app = createApp(App)
const port = browser.runtime.connectNative("browser")
app.config.globalProperties.arif = function(value,condition,type){
    // vale 被判断的值 | condition 期待值数组 | type -> true value被包含在condition中返回真，flase则反之
    var bool = false
    for(var i = 0;i < condition.length;i++){
        if(value == condition[i]){
            bool = true
        }
    }
    if(!type){
        bool = !bool
    }
    return(bool)
}
app.config.globalProperties.PostMessage = function(type,data){
    /* 
    -1,0
    0,0 请求用户信息
    1,0 请求列表
    2,0 请求PassCard列表
    3,[ChatID,MinMessageID] 请求消息
    4,ChatID 请求动态内容
    5,[ChatID,OpinionID] 选项按下
    */
    console.log([type,data])
    port.postMessage([type,data])

    // if(type == 0){
    //     browser.runtime.sendNativeMessage("browser", "2").then(res =>{
    //         //.then是接收正确返回的信息
    //         console.log(res) // {...}
    //     })
    //     .catch(err =>{
    //         // .catch 返回报错信息
    //         console.log(err)
    //     })
        
    // }
    // browser.runtime.sendNativeMessage("browser", "2");
}
port.onMessage.addListener(response => {
    // Let's just echo the message back
    console.log(response)
    
});
app.use(vueI18n)
app.use(VueViewer, {
    defaultOptions: {
        zIndex: 3000,
        inline: false, // Default: false. Enable inline mode.
        button: true, // Show the button on the top-right of the viewer.
        navbar: true, // Specify the visibility of the navbar.
        title: false, // Specify the visibility and the content of the title.
        toolbar: false, // Specify the visibility and layout of the toolbar its buttons.
        tooltip: true, // Show the tooltip with image ratio (percentage) when zooming in or zooming out.
        movable: true, // Enable to move the image.
        zoomable: true, // Enable to zoom the image.
        rotatable: false, // Enable to rotate the image.
        scalable: true, // Enable to scale the image.
        transition: true, // Enable CSS3 Transition for some special elements.
        fullscreen: false, // Enable to request full screen when play.
        keyboard: true, // Enable keyboard support.
        url: 'src', // Default: 'src'. Define where to get the original image URL for viewing.
    }
})
app.mount('#app')