<script>
import { reactive, toRefs } from "vue";
import DLine_Logo from "@/assets/images/DLine.png"
export default{
  setup() {
    const state = reactive({});
    return {
      DLine_Logo
    }
  }, 
  props:{
    UnknownAvatar: String
  },
  data(){
    return{

    }
  },
  components:{
  },
  methods:{
  }
}
</script>
<template>
<div class="Box">
<img class="Avatar" :src="DLine_Logo"/>
<div class="Text">
  <span class="Title">DLine - Pro 1.3</span>
  <br />
  <span></span>
</div>
</div>
</template>
<style scoped>
.Box{
  width: 100%;
  height: 100%;
}
.Avatar{
  float: bottom;
  display: block;
  object-fit: cover;
  overflow: hidden;
  position: relative;
  left: calc(50% - (8em)/2);
  top: 0.8em;
  margin-right: 1em;
  height: 8em;
  width: 8em;
  border-radius: 8em;
}
.Text{
  position: relative;
  width: calc(100% - 4em);
  left: 2em;
  text-align: center;
  word-break: keep-all;
  font-size: 1rem;
}
.Text .Title{
  font-size: 1.2rem;
}
</style>