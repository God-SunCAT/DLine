<script>
let id = 0
export default{
  props:{
    UnknownAvatar: String,
    UserInfo: Array, //['Unknown','error:0','src/assets/images/头像.png'],// 0 name|1 state|2 avatar
    ListData: Array
  },
  data(){
    return{
      //state 0显示激活，1显示冻结，2显示处理(冻结或销毁)
      // ListData: [{id:0,title:"迷失森林 - 让.雷扎",info:"迷失在森林中，你找得到路吗",state:0}]
    }
  },
  methods:{
    GetStoryState(state){
      switch(state){
        case 0:
          return(this.$t("lang.Activation"))
        case 1:
          return(this.$t("lang.Freeze"))
        case 2:
          return(this.$t("lang.Deal"))
      }
    }
  }
}
</script>
<template>
<div class="Box">
  <img
    class="Avatar"
    :src="UserInfo[2]"
    @error="e => { e.target.src = UnknownAvatar }"
  />
  <div class="Text">
    <span class="Title">{{UserInfo[0]}}</span>
    <br />
    <span>{{UserInfo[1]}}</span>
  </div>
  <input type="text" placeholder="PassCard"/>
  <a href="javascript:void(0)">{{$t("lang.ImportPassCard")}}</a>
  <a href="javascript:void(0)">{{$t("lang.ImportFilePassCard")}}</a>
  <ul class="PassCardList">
    <div v-if="ListData.length == 0" class="NoPassCard">
      {{$t("lang.NoPassCard")}}
    </div>
    <li
      v-for="(data,index) in ListData"
      :key="data.id"  
    >
      <div class="StoryInfo">
        <div class="Title">
          {{data.title}}
        </div>
        <br />
        <div class="Introduction">
          {{data.info}}
        </div>
      </div>
      <div class="StoryState">
        {{GetStoryState(data.state)}}
      </div>
      <hr v-if="index == ListData.length - 1?false:true" />
    </li>
  </ul>
</div>
</template>
<style scoped>

.PassCardList{
  position: relative;
  left: 2em;
  top: 1.5em;
  width: calc(100% - 4em);
  height: 20em;
  border-style: solid;
  border-color: #3b3b3ba1;
  border-width: 1.2px;
  border-radius: 1em;
  padding: 0.1em;
  overflow-y: scroll;
}
.PassCardList .NoPassCard{
  width: 100%;
  height: 100%;
  line-height: 20em;
  text-align: center;
  color: #717171;
}
.PassCardList .StoryInfo{
  display: inline-block;
  margin-left: 1em;
  width: calc(100% - 3em - 2em);
  height: 3em;
}

.PassCardList .StoryInfo .Title{
  display: inline-table;
  text-align: center;
  margin-top:0.3em;
  width: 100%;
  font-size: 1rem;
  
}
.PassCardList .StoryInfo .Introduction{
  display: inline-block;
  text-align: center;
  width: 100%;
  font-size: 0.8rem;
}
.PassCardList .StoryState{
  display: inline-block;
  max-height: 3em;
  width: 3em;
  color: #3b8edc;
  text-align: center;
  line-height: 3em;
}
.Box{
  width: 100%;
  height: 100%;
  overflow-y: scroll;
}
.Avatar{
  float: bottom;
  display: block;
  object-fit: cover;
  overflow: hidden;
  position: relative;
  left: calc(50% - (5em)/2);
  top: 0.8em;
  margin-right: 1em;
  height: 5em;
  width: 5em;
  border-radius: 5em;
  margin-bottom: 1.5em;
}
.Text{
  display: block;
  position: relative;
  width: calc(100% - 4em);
  left: 2em;
  text-align: center;
  word-break: keep-all;
  font-size: 1rem;
}
.Text .Title{
  font-size: 1.2rem;
}
input{
  display: block;
  position: relative;
  border-style: solid;
  border-color: #3b3b3ba1;
  border-width: 1.2px;
  border-radius: 1em;
  padding: 0.1em;
  top: 1em;
  width: calc(100% - 4em);
  height: 2.4rem;
  left: 2em;
  text-align: center;
}
a{
  display: block;
  position: relative;
  top: 1.5em;
  left: 2em;
  margin-bottom: 0.4em;
  height: 2.4em;
  width: calc(100% - 4em);
  line-height: 2.4em;
}
a:link, a:visited{
  background-color: #1c1c1c;
  color: #3b8edc;
  fill: #3b8edc;
  border-radius: 1rem;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  white-space: nowrap;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
a:active{
  color: #1c4074;
  fill: #1c4074;
  background-color: #0b0b0b;
}
</style>