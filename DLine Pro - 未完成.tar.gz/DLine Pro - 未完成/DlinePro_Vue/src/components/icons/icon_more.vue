<script>
export default{

}
</script>
<template>
<a href="javascript:void(0)">
    <svg id="SvgBox" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="1.8rem" hight="1.8rem"><path d="M10.4 26.4q-1 0-1.7-.7T8 24q0-1 .7-1.7t1.7-.7q1 0 1.7.7t.7 1.7q0 1-.7 1.7t-1.7.7Zm13.6 0q-1 0-1.7-.7t-.7-1.7q0-1 .7-1.7t1.7-.7q1 0 1.7.7t.7 1.7q0 1-.7 1.7t-1.7.7Zm13.6 0q-1 0-1.7-.7t-.7-1.7q0-1 .7-1.7t1.7-.7q1 0 1.7.7T40 24q0 1-.7 1.7t-1.7.7Z"/></svg>
    <br />
    <span>{{$t('lang.more')}}</span>
</a>
</template>
<style scoped>
a{
    display: inline-block;
    position: relative;
    left: 1rem;
    height: 3.5rem;
    width: 6rem;
}
a:link, a:visited{
    background-color: #1c1c1c;
    color: #3b8edc;
    fill: #3b8edc;
    border-radius: 1rem;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    white-space: nowrap;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
a:active {
  color: #1c4074;
  fill: #1c4074;
  background-color: #0b0b0b;
}
#SvgBox{
    position: relative;
    top: 0.5rem;
    float: top;
}
span{
    color: inherit;
    display: inline-block;
    position: relative;
    bottom: 0.2rem;
    width: 3.5rem;
    font-size: 0.6rem;
    text-align: center;
}
</style>