<script>
export default{
    props:{
        color: String // #999999 未选中 | #0066cc 选中
    }
}
</script>
<template>
<div id="box">
    <svg id="SvgBox" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="2rem" hight="2rem" :fill="color"><path d="M44 11v26q0 1.2-.9 2.1-.9.9-2.1.9H7q-1.2 0-2.1-.9Q4 38.2 4 37V11q0-1.2.9-2.1Q5.8 8 7 8h34q1.2 0 2.1.9.9.9.9 2.1ZM7 16.45h34V11H7Zm0 6.45V37h34V22.9ZM7 37V11v26Z"/></svg>
    <br />
    <span :color="color">{{ $t('lang.PassCard')}}</span>
</div>
</template>
<style scoped>
#box{
    display: inline-block;
    position: fixed;
    /* left: calc((100% - 9rem)/3 - 1rem);  */
    left: calc(25% - 3rem); 
    width: 3rem;
    height: 3.1rem;
    overflow: hidden;
    line-height: 0.6em;
}
#SvgBox{
    float: top;
    margin-left: 0.5rem;
}
span{
    display: inline-block;
    width: 3rem;
    font-size: 0.6rem;
    text-align: center;
}
</style>