<script>
export default{

}
</script>
<template>
<a href="javascript:void(0)">
    <svg id="SvgBox" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="1.8rem" hight="1.8rem"><path d="M39.8 41.95 26.65 28.8q-1.5 1.3-3.5 2.025-2 .725-4.25.725-5.4 0-9.15-3.75T6 18.75q0-5.3 3.75-9.05 3.75-3.75 9.1-3.75 5.3 0 9.025 3.75 3.725 3.75 3.725 9.05 0 2.15-.7 4.15-.7 2-2.1 3.75L42 39.75Zm-20.95-13.4q4.05 0 6.9-2.875Q28.6 22.8 28.6 18.75t-2.85-6.925Q22.9 8.95 18.85 8.95q-4.1 0-6.975 2.875T9 18.75q0 4.05 2.875 6.925t6.975 2.875Z"/></svg>
    <br />
    <span>{{$t('lang.search')}}</span>
</a>
</template>
<style scoped>
a{
    display: inline-block;
    position: relative;
    left: 0.5rem;
    height: 3.5rem;
    width: 6rem;
}
a:link, a:visited{
    background-color: #1c1c1c;
    color: #3b8edc;
    fill: #3b8edc;
    border-radius: 1rem;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    white-space: nowrap;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
a:active {
  color: #1c4074;
  fill: #1c4074;
  background-color: #0b0b0b;
}
#SvgBox{
    position: relative;
    top: 0.5rem;
    float: top;
}
span{
    color: inherit;
    display: inline-block;
    position: relative;
    bottom: 0.2rem;
    width: 3.5rem;
    font-size: 0.6rem;
    text-align: center;
}
</style>