<script>
export default{
    props:{
        color: String // #999999 未选中 | #0066cc 选中
    }
}
</script>
<template>
<div id="box">
    <svg id="SvgBox" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="2rem" hight="2rem" :fill="color"><path d="M4 34V6.1q0-.7.65-1.4T6 4h25.95q.75 0 1.4.675Q34 5.35 34 6.1v17.8q0 .7-.65 1.4t-1.4.7H12Zm10.05 2q-.7 0-1.375-.7T12 33.9V29h25V12h5q.7 0 1.35.7.65.7.65 1.45v29.8L36.05 36ZM31 7H7v19.75L10.75 23H31ZM7 7v19.75Z"/></svg>
    <br />
    <span :color="color">{{ $t('lang.message')}}</span>
</div>
</template>
<style scoped>
#box{
    display: inline-block;
    position: fixed;
    /* left: calc((100% - 9rem)/3 * 2); */
    left: calc(50% - 2rem);
    width: 3rem;
    height: 3.1rem;
    overflow: hidden;
    line-height: 0.6em;
}
#SvgBox{
    float: top;
    margin-left: 0.5rem;
}
span{
    display: inline-block;
    width: 3rem;
    font-size: 0.6rem;
    text-align: center;
}
</style>