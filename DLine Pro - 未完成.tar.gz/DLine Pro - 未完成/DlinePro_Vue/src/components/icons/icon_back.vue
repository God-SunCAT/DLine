<script>
export default{
}
</script>
<template>
<div id="box">
    <svg id="SvgBox" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="1.5rem" hight="1.5rem" fill="#999999"><path d="M20 44 0 24 20 4l2.8 2.85L5.65 24 22.8 41.15Z"/></svg>
</div>
</template>
<style scoped>
#box{
    z-index: 1;
    display: inline-block;
    position: fixed;
    /* left: calc((100% - 9rem)/3 * 2); */
    top: 0.5rem;
    left: 0rem;
    width: 2rem;
    height: 2rem;
    overflow: hidden;
}
#SvgBox{
    float: top;
    margin-left: 0.5rem;
}
</style>