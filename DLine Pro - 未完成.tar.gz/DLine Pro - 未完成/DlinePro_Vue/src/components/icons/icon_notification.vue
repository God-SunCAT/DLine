<script>
export default{
    props:{
        state: String //A为 mute|B 为unmute
    }
}
</script>
<template>
<a href="javascript:void(0)">
    <svg id="SvgBox" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="1.8rem" hight="1.8rem"><path :d="state=='A'?'M8 38v-3h4.2V19.7q0-4.2 2.475-7.475Q17.15 8.95 21.2 8.1V6.65q0-1.15.825-1.9T24 4q1.15 0 1.975.75.825.75.825 1.9V8.1q4.05.85 6.55 4.125t2.5 7.475V35H40v3Zm16-14.75ZM24 44q-1.6 0-2.8-1.175Q20 41.65 20 40h8q0 1.65-1.175 2.825Q25.65 44 24 44Zm-8.8-9h17.65V19.7q0-3.7-2.55-6.3-2.55-2.6-6.25-2.6t-6.275 2.6Q15.2 16 15.2 19.7Z':'M8 38v-3h4.2V19.25q0-1.5.425-2.925Q13.05 14.9 13.8 13.6l2.25 2.25q-.4.85-.625 1.675-.225.825-.225 1.725V35H31L3.75 7.75l2.1-2.1L42.15 42l-2.1 2.1-6.1-6.1Zm27.85-6.6-3-3v-8.7q0-3.75-2.525-6.325T24.1 10.8q-1.75 0-3.35.575T17.8 13.35l-2.15-2.15Q17 9.9 18.375 9.175 19.75 8.45 21.2 8.1V6.8q0-1.15.825-1.975Q22.85 4 24 4q1.15 0 1.975.825.825.825.825 1.975v1.3q3.9.85 6.475 4.1 2.575 3.25 2.575 7.5ZM23.1 27.1ZM24 44q-1.65 0-2.825-1.175Q20 41.65 20 40h8q0 1.65-1.175 2.825Q25.65 44 24 44Zm1.35-23.15Z'"/></svg>
    <br />
    <span>{{state=='A'?$t('lang.notice_mute'):$t('lang.notice_unmute')}}</span>
</a>
</template>
<style scoped>
a{
    display: inline-block;
    height: 3.5rem;
    width: 6rem;
}
a:link, a:visited{
    background-color: #1c1c1c;
    color: #3b8edc;
    fill: #3b8edc;
    border-radius: 1rem;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    white-space: nowrap;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
a:active {
  color: #1c4074;
  fill: #1c4074;
  background-color: #0b0b0b;
}
#SvgBox{
    position: relative;
    top: 0.5rem;
    float: top;
}
span{
    color: inherit;
    display: inline-block;
    position: relative;
    bottom: 0.2rem;
    width: 3.5rem;
    font-size: 0.6rem;
    text-align: center;
}
</style>