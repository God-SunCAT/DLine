<script>
export default{
    props:{
        color: String // #999999 未选中 | #0066cc 选中
    }
}
</script>
<template>
<div id="box">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="1.5rem" hight="1.5rem" :fill="color"><path d="M35.8 42H13.6V16.4L27.5 2l1.95 1.55q.3.25.45.7.15.45.15 1.1v.5L27.8 16.4h14.95q1.2 0 2.1.9.9.9.9 2.1v4.1q0 .35.075.725t-.075.725l-6.3 14.5q-.45 1.05-1.475 1.8Q36.95 42 35.8 42Zm-19.2-3h19.85l6.3-14.95V19.4H24.1l2.65-12.45-10.15 10.7Zm0-21.35V39Zm-3-1.25v3H6.95V39h6.65v3H3.95V16.4Z"/></svg>
</div>
</template>
<style scoped>
#box{
    float: right;
    display: inline-block;
    position: relative;
    /* right: calc((100% - 9rem)/3 - 1rem); */ 
    right: 1rem;
    width: 1.5rem;
    height: 1.5rem;
    overflow: hidden;
}
</style>