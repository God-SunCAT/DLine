<script>
export default{
    props:{
        color: String // #999999 未选中 | #0066cc 选中
    }
}
</script>
<template>
<div id="box">
    <svg id="SvgBox" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="2rem" hight="2rem" :fill="color"><path d="M24 44q-4.15 0-7.8-1.575-3.65-1.575-6.35-4.275-2.7-2.7-4.275-6.35Q4 28.15 4 24t1.575-7.8Q7.15 12.55 9.85 9.85q2.7-2.7 6.35-4.275Q19.85 4 24 4t7.8 1.575q3.65 1.575 6.35 4.275 2.7 2.7 4.275 6.35Q44 19.85 44 24t-1.575 7.8q-1.575 3.65-4.275 6.35-2.7 2.7-6.35 4.275Q28.15 44 24 44Zm-2.15-3.05v-4.1q-1.75 0-2.95-1.3-1.2-1.3-1.2-3.05v-2.2L7.45 20.05q-.25 1-.35 1.975Q7 23 7 24q0 6.5 4.225 11.35t10.625 5.6Zm14.7-5.4q1.1-1.2 1.925-2.55.825-1.35 1.4-2.825t.85-3.025Q41 25.6 41 24q0-5.3-2.9-9.625T30.35 8.05v.9q0 1.75-1.2 3.05-1.2 1.3-2.95 1.3h-4.35v4.35q0 .85-.675 1.4-.675.55-1.525.55H15.5V24h12.9q.85 0 1.4.65.55.65.55 1.5v6.35h2.15q1.45 0 2.55.85 1.1.85 1.5 2.2Z"/></svg>
    <br />
    <span :color="color">{{ $t('lang.public')}}</span>
</div>
</template>
<style scoped>
#box{
    display: inline-block;
    position: fixed;
    /* right: calc((100% - 9rem)/3 - 1rem); */
    right: calc(25% - 3rem); 
    width: 3rem;
    height: 3.1rem;
    overflow: hidden;
    line-height: 0.6em;
}
#SvgBox{
    float: top;
    margin-left: 0.5rem;
}
span{
    display: inline-block;
    width: 3rem;
    font-size: 0.6rem;
    text-align: center;
}
</style>