<script>
export default{
    props:{
        color: String // #999999 未选中 | #0066cc 选中
    }
}
</script>
<template>
<div id="box">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="1.5rem" hight="1.5rem" :fill="color"><path d="M6 38h3v-8.7q0-2.7 1.9-4.6 1.9-1.9 4.6-1.9h20.8l-7.7 7.7 2.1 2.1L42 21.3 30.7 10l-2.1 2.1 7.7 7.7H15.5q-3.9 0-6.7 2.775Q6 25.35 6 29.3Z"/></svg>
</div>
</template>
<style scoped>
#box{
    float: right;
    display: inline-block;
    position: relative;
    /* right: calc((100% - 9rem)/3 - 1rem); */ 
    width: 1.5rem;
    height: 1.5rem;
    overflow: hidden;
}
</style>