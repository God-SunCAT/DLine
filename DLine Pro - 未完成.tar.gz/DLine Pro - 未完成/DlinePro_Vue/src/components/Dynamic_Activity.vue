<script>
import icon_notification from './icons/icon_notification.vue';
import icon_more from './icons/icon_more.vue';
import icon_log from './icons/icon_log.vue';
import icon_ThumbUp from './icons/icon_ThumbUp.vue';
import icon_forward from './icons/icon_forward.vue';
let id = 0
export default{
  props:{
    UnknownAvatar: String,
    ListData: Array,
    UserInfo: Array,
    ChatUserInfo: Array
  },
  components:{
    icon_notification,
    icon_log,
    icon_more,
    icon_ThumbUp,
    icon_forward
  },
  data(){
      return{
        // ChatUserInfo:['Unknown','Introduction','Avatar',0,0,0],//Name|Introduction|Avatar|Sex|Push|Online && Push Model -> 0 Push | 1 unPush && Online -> 0 No | 1 Yes
        // ListData:[
        //   //最多9张照片
        //   {id:id++,avatar:'http://192.168.1.4:8000/src/assets/images/我出门啦.jpg',name:"凌",time:'07-09 20:48',message:"今天又是元气满满的一天呢(^ v ^)",image:['http://192.168.1.4:8000/src/assets/images/我出门啦.jpg']}
        // ]
      }
  },
  created(){
    this.PostMessage(4,this.ChatUserInfo[6]);
  },
  methods:{
    ImageClassIF(number){
      var Tclass = ""
      switch(number){
        // 1张
        // 2张=4张
        // 3，5，6，7，8=9张
        case 1:
          Tclass = 'Dynamic_Image1'
          break
        case 2:
          Tclass = 'Dynamic_Image24'
          break
        case 4:
          Tclass = 'Dynamic_Image24'
          break
        default:
          Tclass = 'Dynamic_Image9'
          break
      }
      return Tclass
    }
  }
}
</script>
<template>
<div class="Box">
    <div id="UserInfoBox">
        <img
          class="Avatar"
          :src="UserInfo[2]"
          @error="e => { e.target.src = UnknownAvatar }"
        />
        <div class="UserName">{{UserInfo[0]}}</div>
        <div class="UserIntroduction">{{UserInfo[1]}}</div>
        <div id="ButtonBox">
          <icon_notification :state="UserInfo[4]==0?'A':'B'" />
          <icon_log />
          <icon_more />
        </div>
    </div>
    <ul>
      <li
        class="Dynamic_Box"
        v-for="data in ListData"
        :key="data.id"
      >
        <div class="Dynamic_Header">
          <img
            class="Avatar"
            :src="data.avatar"
            @error="e => { e.target.src = UnknownAvatar }"
          />
          <div class="info">
            <span class="Username">{{data.name}}</span>
            <br />
            <span class="time">{{data.time}}</span>
          </div>
        </div>
        <div class="Dynamic_Body">{{data.message}}</div>
        <div class="Dynamic_Body">
          <div 
            v-if="data.image.length > 0" 
            :class="ImageClassIF(data.image.length)" 
            v-viewer
          >
            <div class="img" v-for="img in data.image">
              <img :src="img" />
            </div>
          </div>
        </div>
        <div class="Dynamic_Body">
        <icon_forward color="#999999" />
        <icon_ThumbUp color="#999999" />
        </div>
      </li>
    </ul>
</div>
</template>
<style scoped>
/* 在一些平板上图片会出现滑动框（因为50%或者33.33%的宽度都超过了26.5rem） */
.Dynamic_Image1 img{
  object-fit: cover;
  /* ！固定！ */
  max-height: 26.5rem;
  max-width: 100%;
}
.Dynamic_Image24{
  overflow: hidden;
  width: 100%;
  /* height加上的1px是中间的空隙 */
  max-height: calc(26.5rem + 1px);
  line-height: 0;
}
  .Dynamic_Image24 .img{
    display: inline-block;
    position:relative;
    /* width减去的1px是中间的空隙 */
    width:calc(50% - 1px); 
    margin-right: 1px;
    margin-bottom: 1px;
    height:0;
    padding-top:50%;
  }
  .Dynamic_Image24 .img img{
    width:100%;
    height:100%;
    top:0;
    left:0;
    position: absolute;
    object-fit: cover;
  }
.Dynamic_Image9{
  width: 100%;
  max-height: calc(26.5rem + 2px);
  line-height: 0;
}
  .Dynamic_Image9 .img{
    display: inline-block;
    position:relative;
    width:calc(100%/3 - 2px);
    margin-right: 1px;
    margin-bottom: 1px;
    height:0;
    padding-top:calc(100%/3);
  }
  .Dynamic_Image9 .img img{
    width:100%;
    height:100%;
    top:0;
    left:0;
    position: absolute;
    object-fit: cover;
  }
.Box{
  overflow-x: hidden;
  overflow-y: scroll;
  width: 100%;
  height: 100%;
}
#UserInfoBox{
  width: 100%;
  height: 13rem;
  overflow: hidden;
  box-sizing: border-box;
  border-bottom: 1px solid #1d1d1da1;
}
#ButtonBox{
  position: relative;
  width: calc(3*(6rem) + 2*(0.5rem));
  top: 1rem;
  left: calc(50% - (3*(6rem) + 2*(0.5rem))/2) ;
}
.Dynamic_Box{
  box-sizing: border-box;
  border-bottom: 1px solid #1d1d1da1;
  padding-bottom: 0.425rem;
  overflow: hidden;
  zoom: 1;
}
.Dynamic_Header{
  width: 100%;
  height: 3.5em;
  display: block;
}
.Dynamic_Header .info{
  position: relative;
  top: 0.425rem;
}
.Dynamic_Header .info .time{
  font-size: 0.7rem;
  line-height: 1rem;
  color: #fafafa98;
}
.Dynamic_Header .Avatar{
  object-fit: cover;
  overflow: auto;
  float: left;
  position: relative;
  top: 0.425em;
  left: 0.5em;
  margin-right: 1em;
  height: 2.65em;
  width: 2.65em;
  border-radius: 2.65em;
}
.Dynamic_Body{
  overflow-x: hidden;
  position: relative;
  left: 0.5rem;
  width: calc(100% - 1rem);
  word-wrap: break-word;
  padding-bottom: 0.425rem;
  box-sizing: border-box;
  /* border-bottom: 1px solid #1d1d1da1; */
}
.Avatar{
  display: block;
  object-fit: cover;
  overflow: hidden;
  position: relative;
  left: calc(50% - (5em)/2);
  top: 0.425em;
  margin-right: 1em;
  height: 5em;
  width: 5em;
  border-radius: 5em;
}
.UserName{
  width: 100%;
  height: 2rem;
  font-size: 1.2rem;
  text-align: center;
  line-height: 3rem;
  white-space: nowrap;
}
.UserIntroduction{
    color: #8f8e94;
    height: 1rem;
    width: 100%;
    font-size: 1rem;
    text-align: center;
    white-space: nowrap;
}
</style>