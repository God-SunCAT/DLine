<script>
import { withCtx } from 'vue';
import Pull_Refresh from './Pull_Refresh.vue';
export default{
  props:{
    UnknownAvatar: String,
    ListData: Array,
    Opinion_Info: Array,
    ChatUserInfo: Array
  },
  components:{
    Pull_Refresh
  },
  data(){
    return{
        // ListData:[
        //     //type消息类型 UserType气泡旁有无头像和名称，从哪里读取头像和名称
        //     // {id:id++,message:"嗨嗨",time:'PM8:20',type:0,avatar:"",name:""}
        //     // 0 对方|1 我 具体再扩展|2 对方图片|3 我方图片
        //     {id:id++,message:"嗨嗨",time:'PM8:20',type:0},
        // ],
        // Opinion_Info:[false,'OpA','OpB']
        PR_Setting:[0,this.$t("lang.PR_Top.Refresh.A"),this.$t("lang.PR_Top.Refresh.B"),this.$t("lang.PR_Top.Refresh.C"),this.$t("lang.PR_Top.Refresh.D"),this.$t("lang.PR_Top.Refresh.E")]
    }
  },
  created(){
    if(this.ListData.length == 0){
        this.PostMessage(3,[this.ChatUserInfo[6],0]);
    }else{
        this.PostMessage(3,[this.ChatUserInfo[6],this.ListData[0].id]);
    }
  },
  methods:{
    refresh(){
        // this.ListData.unshift({id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0},{id:0,message:"ssss",time:'PM8:20',type:0})
        this.$nextTick(function(){
            this.$refs.loading.refresh()
        })
    },
    RefreshData(){
        this.$nextTick(function(){
            this.$refs.loading.refresh()
        })
    },
    Click_Opinion(type){
        if(type == 1){
            //选项一
            this.PostMessage(5,[ChatUserInfo[6],1]);
        }
        else{
            //选项二
            this.PostMessage(5,[ChatUserInfo[6],2]);
        }
    }
  }
}
</script>
<template>
<div class="Box">
<ul 
    class="MessageBox"
    :style="{
        height:(Opinion_Info[0]?'calc(100% - 6rem)':'100%')
    }" 
    >
    <Pull_Refresh @refresh="refresh" ref="loading" :setting="PR_Setting">
    <li
        class="List_Message"
        v-for="data in ListData"
        :key="data.id"
    >
        <div class="Chat_Person">
            <div :class="data.type == 0?'OthersMessage':'SelfMessage'">
                <div class="Message-Content">
                    <span v-if="data.type == 0 || data.type == 1" class="text">{{data.message}}</span>
                    <img v-if="data.type == 2 || data.type == 3" :src="data.message">
                    <div class="info">{{data.time}}</div>
                </div>
            </div>
        </div>
    </li>
    </Pull_Refresh>
</ul>
<div
    class="OpinionBox"
    :style="{
        height:(Opinion_Info[0]?'6rem':'0')
    }"
>
    <a class="OpA" href="javascript:void(0)" @click="Click_Opinion(1)">{{Opinion_Info[1]}}</a>
    <a class="OpB" href="javascript:void(0)" @click="Click_Opinion(2)">{{Opinion_Info[2]}}</a>
</div>
</div>
</template>
<style scoped>
.Box{
  width: 100%;
  height: 100%;
}
.MessageBox{
    overflow-x: hidden;
    overflow-y: scroll;
    height: 100%;
    transition: height 0.5s ease;
}
.OpinionBox{
    box-sizing: border-box;
    border-top: 1px solid #3b3b3ba1;
    height: 0;
    transition: height 0.5s ease;
}
.OpinionBox .OpA{
    position: relative;
    left: 0.1rem;
    top: 0.1rem;
    height: 2.7rem;
    width: calc(100% - 0.2rem);
    line-height: 2.7rem;
}
.OpinionBox .OpB{
    position: relative;
    left: 0.1rem;
    top: 0.4rem;
    height: 2.7rem;
    width: calc(100% - 0.2rem);
    line-height: 2.7rem;
}
.OpinionBox a:link, a:visited{
    background-color: #5a5a5a;
    color: #ffffff;
    /* padding: 14px 25px; */
    border-radius: 1rem;
    vertical-align: middle;
    text-align: center;
    text-decoration: none;
    display: block;
    white-space: nowrap;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
.OpinionBox a:active {
  background-color: #424242;
}
.List_Message{
    margin-bottom: 0.5em;
}
.Chat_Person{
    overflow: hidden;
    zoom: 1;
}
.Chat_Person .SelfMessage{
    max-width: 75%;
    float: right;
    position: relative;
    right: 0.5rem;
    background-color: rgb(7, 58, 134);
    border: 1px solid rgb(7, 61, 140);
    border-radius: 1rem 1rem 0 1rem;
}
.Chat_Person .OthersMessage{
    max-width: 75%;
    float: left;
    position: relative;
    left: 0.5rem;
    background-color: rgb(26, 26, 26);
    border: 1px solid rgb(26, 26, 26);
    border-radius: 1rem 1rem 1rem 0;
}
.Chat_Person .Message-Content{
    overflow: hidden;
    margin: 0.3rem;
    /* margin: 0.3rem 0.3rem 0rem 0.3rem; */
}
.Chat_Person .Message-Content img{
    display: block;
    border-radius: 0.2rem;
    object-fit: cover;
    max-width: 100%;
    max-height: 25rem;
}
.Chat_Person .Message-Content .info{
    /* display: block; */
    font-size: 0.7rem;
    position: relative;
    float: right;
    line-height: 1rem;
    vertical-align: bottom;
    color: #fafafa98;
}
.Chat_Person .Message-Content .text{
    word-wrap: break-word;
}
</style>