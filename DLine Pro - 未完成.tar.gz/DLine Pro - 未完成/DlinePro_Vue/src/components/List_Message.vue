<script>
let id = 0
export default{
  props:{
    ListData: Array,
    UnknownAvatar: String
  },
  data(){
    return{
      // ListData:[
      //   {id: id++,avatar:'http://192.168.1.4:8000/src/assets/images/我出门啦.jpg',name:"Dline - 迈向星辰大海！",content:'浮生拍了拍你的共享木鱼 功德+1',time:"PM8:20",unread:"1"}
      // ]
    }
  },
  methods:{
    Click_ChatList(id){
      this.$emit('ComEvent',1,0,id)
    }
  }
}
</script>
<template>
<div class="Box">
    <ul>
        <!-- key  number | string | symbol-->
        <li id="NoticeBox">{{$t('lang.SelfOnly')}}</li>
        <li
          class="List"
          v-for="data in ListData"
          :key="data.id"
          @click="Click_ChatList(data.id)"
        > 
          <img
            class="Avatar"
            :src="data.avatar"
            @error="e => { e.target.src = UnknownAvatar }"
          />
          <div class="List_UserInfo">
            <span class="List_User_Name">{{data.name}}</span>
            <br />
            <span class="List_User_Content">{{data.content}}</span>
          </div>
          <div class="Message_Info">
            <span class="time">{{data.time}}</span>
            <br />
            <span class="unread">{{data.unread}}</span>
          </div>
        </li>
    </ul>
</div>
</template>
<style scoped>
.Box{
  overflow-x: hidden;
  overflow-y: scroll;
  width: 100%;
  height: 100%;
}
.Avatar{
  object-fit: cover;
  float: left;
  position: relative;
  top: 0.3em;
  left: 0.5em;
  margin-right: 1em;
  height: 3.2em;
  width: 3.2em;
  border-radius: 50px;
}
.List{
  list-style: none;
  position: relative;
  width: 100%;
  /* height: 3.8em;/* Avatar height+top*2 */
  height: 4.5em;
}
li.List:active{
  background-color: #171717;
}
.List_UserInfo{
  width: 100%;
  position: relative;
  top: 1.1em;
  line-height: 1em;
}
.List_User_Name{
  position: absolute;
  width: calc(100% - 3.7rem - 3rem);
  text-overflow: ellipsis;
  overflow: hidden;
  color: #ffffff;
  font-size: 1.1rem;
}
.List_User_Content{
  position: absolute;
  top: 1.2rem;
  width: calc(100% - 3.7rem - 3rem);
  text-overflow: ellipsis;
  overflow: hidden;
  color: #8d8d92;
  font-size: 0.8em;
}
#NoticeBox{
    list-style: none;
    text-align: center;
    line-height: 1.5em;
    width: 100%;
    height: 1.5rem;
    border-bottom: 1px solid #535353;
}
.Message_Info{
    float: right;
    position: relative;
    right: 0.385rem;
}
.time{
    color: #8d8d92;
    font-size: 0.7rem;
}
.unread{
    float: right;
    border-radius: 10px;
    color: black;
    display: inline-block;
    font-size: 12px;
    height: 18px;
    line-height: 18px;
    padding: 0 6px;
    text-align: center;
    white-space: nowrap;
    background-color: #757575;

}
</style>