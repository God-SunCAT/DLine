this.addEventListener('fetch', function(event) {
    //fetch返回response对象
    // https://developer.mozilla.org/zh-CN/docs/Web/API/Response/Response
    if(event.request.url.indexOf("api/") == -1){
        event.respondWith(fetch(event.request));
    }else{
        var data = event.request.url.substring(event.request.url.indexOf("api/") + 4).split("/")
        console.log(data)
        event.respondWith(new Response("aac",  { "status" : 200 , "statusText" : "Good!" }));
    }
});