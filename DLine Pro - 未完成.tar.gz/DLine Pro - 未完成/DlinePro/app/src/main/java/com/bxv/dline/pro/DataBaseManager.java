package com.bxv.dline.pro;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class DataBaseManager {
    // 释放什么的没必要就不写了
    private static List<DBHelper> DataBase = new ArrayList();
    public static synchronized void initializeInstance(DBHelper helper) {
        DataBase.add(helper);
    }
    public static synchronized SQLiteDatabase openDatabase(int index) {
        return(DataBase.get(index).getWritableDatabase());
    }
    public static synchronized SQLiteDatabase openDatabase_ReadOnly(int index) {
        return(DataBase.get(index).getReadableDatabase());
    }
}