package com.bxv.dline.pro;

import android.app.Activity;
import android.content.Context;
import android.content.res.AssetManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.mozilla.geckoview.AllowOrDeny;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.WebExtension;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    private static GeckoRuntime sRuntime;
    private SQLiteDatabase TempDataBase;
    private GeckoView view;
    private ImageView Load_ImageView;
    private GeckoSession session;
    private GeckoRuntime runtime;
    private WebExtension.Port mPort;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String SQL;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //初始化
        view = findViewById(R.id.activity_main_geckoview);
        Load_ImageView = findViewById(R.id.activity_main_LoadImgView);
        session = new GeckoSession();
        runtime = GeckoRuntime.create(this);
        session.open(runtime);
        view.setSession(session);
        //---
        DataBaseManager.initializeInstance(new DBHelper(this, "DlineData.db", null, 1));//index 0 始终为系统数据库
        DataBase.InitSystemDataBase();
        //---
        runtime.getWebExtensionController()
                .ensureBuiltIn("resource://android/assets/ComPlugin/", "messaging@example.com")
                .accept(
                        extension -> {
                            SetMessageDelegate(extension);
                            session.loadUri(extension.metaData.baseUrl+"WebUI/index.html");
//                            session.loadUri(extension.metaData.baseUrl+"main.html");
                        },
                        e -> Log.e("MessageDelegate", "Error registering WebExtension", e)
                );
        //----
        runtime.getSettings().setRemoteDebuggingEnabled(true);
        //----
    }
    private void SetMessageDelegate(WebExtension extension){
        session.getWebExtensionController().setMessageDelegate(extension,messageDelegate,"browser");

    }
    //----
    WebExtension.PortDelegate portDelegate = new WebExtension.PortDelegate() {
        public WebExtension.Port port = null;

        public void onPortMessage(final @NonNull Object message,
                                  final @NonNull WebExtension.Port port) {
            Load_ImageView.setVisibility(View.GONE);
            if(message instanceof JSONArray){
                JSONArray json = (JSONArray)message;
                if(json.length() == 2){
                    int G_index = -1;
                    JSONArray G_Array;
                    try {
                        G_index = json.getInt(0);
                        G_Array = json.getJSONArray(1);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    switch (G_index){
                        case -1:    //读取json失败
                            return;
                        case 0: //获取用户信息 启动时第一个被调用
                            if(Load_ImageView.getVisibility() != view.GONE){    //判断窗口是否被显示
                                Load_ImageView.setVisibility(View.GONE);
                            }
                            break;
                    }
                }
            }
        }

        public void onDisconnect(final @NonNull WebExtension.Port port) {
            // After this method is called, this port is not usable anymore.
            if (port == mPort) {
                mPort = null;
            }
        }
    };

    WebExtension.MessageDelegate messageDelegate = new WebExtension.MessageDelegate() {
        @Nullable
        public GeckoResult<Object> onMessage(final @NonNull String nativeApp,
                                             final @NonNull Object message,
                                             final @NonNull WebExtension.MessageSender sender) {
            // The sender object contains information about the session that
            // originated this message and can be used to validate that the message
            // has been sent from the expected location.

            // Be careful when handling the type of message as it depends on what
            // type of object was sent from the WebExtension script.
            final GeckoResult<Object> result = new GeckoResult<>();
            result.complete(readFileFromAssets(getBaseContext(),null,"ComPlugin/WebUI/assets/DLine.2c484794.png"));
//            result.complete("AAAAAAAAAA");
            return(result);
//            return null;
        }
        @Nullable
        public void onConnect(final @NonNull WebExtension.Port port) {
            // Let's store the Port object in a member variable so it can be
            // used later to exchange messages with the WebExtension.
            mPort = port;
            // Registering the delegate will allow us to receive messages sent
            // through this port.
            mPort.setDelegate(portDelegate);
        }
    };
    public static byte[] readFileFromAssets(Context context, String groupPath, String filename) {
        byte[] buffer = null;
        AssetManager am = context.getAssets();
        try {
            InputStream inputStream = null;
            if (groupPath != null) {
                inputStream = am.open(groupPath + "/" + filename);
            } else {
                inputStream = am.open(filename);
            }

            int length = inputStream.available();
//            Log.d(TAG, "readFileFromAssets length:" + length);
            buffer = new byte[length];
            inputStream.read(buffer);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return buffer;
    }
}
