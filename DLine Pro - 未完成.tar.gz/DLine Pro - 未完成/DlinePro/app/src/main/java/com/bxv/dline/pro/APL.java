package com.bxv.dline.pro;

import android.app.Application;
import android.util.Log;

public class APL extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }

}
