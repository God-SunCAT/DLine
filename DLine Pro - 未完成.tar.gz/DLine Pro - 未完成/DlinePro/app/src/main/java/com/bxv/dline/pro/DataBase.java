package com.bxv.dline.pro;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class DataBase {
    private static SQLiteDatabase SystemDataBase;
    public static void InitSystemDataBase(){
        String SQL;
        SystemDataBase = DataBaseManager.openDatabase(0);
        //引入了数据库
        SQL = "CREATE TABLE IF NOT EXISTS \"Source\" (\n" +
                "  \"ID\" integer NOT NULL PRIMARY KEY AUTOINCREMENT,\n" +
                "  \"SourceID\" text,\n" +
                "  \"Body\" blob\n" +
                ");";
        SystemDataBase.execSQL(SQL);
    }
    @SuppressLint("Range")
    public static byte[] System_GetSource(String SourceID){
        byte[] value = null;
        Cursor cursor = SystemDataBase.rawQuery("Select * From Source Where `SourceID` = ?",new String[]{SourceID});
        if(cursor.getCount() != 0) {
            if (cursor.moveToNext()) {
                value = cursor.getBlob(cursor.getColumnIndex("Body"));
            }
        }
        cursor.close();
        return value;
    }
    @SuppressLint("Range")
    public static String System_GetSource_String(String SourceID){
        String value = null;
        Cursor cursor = SystemDataBase.rawQuery("Select * From Source Where `SourceID` = ?",new String[]{SourceID});
        if(cursor.getCount() != 0) {
            if (cursor.moveToNext()) {
                value = cursor.getString(cursor.getColumnIndex("Body"));
            }
        }
        cursor.close();
        return value;
    }
}
