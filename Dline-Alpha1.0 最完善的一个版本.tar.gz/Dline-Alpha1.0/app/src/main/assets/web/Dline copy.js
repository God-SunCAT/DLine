$("#Activity_Set").hide()
$("#Activity_Space").hide()
//----------------------------------------------
//事件函数
function Click_OpinionA(){
  Set_OpinionState(0)
  // Worker1.postMessage([3,1])//选项按下
}
function Click_OpinionB(){
  Set_OpinionState(0)
  // Worker1.postMessage([3,2])
}
function Click_Menu(){
  $("#Set_Box_LinkInput").val("")
  $("#Set_Box_LinkInput").attr("placeholder", "PassCard")
  $("#Activity_Chat").hide()
  $("#Activity_Set").show()
}
function Click_Return_Set(){
  $("#Activity_Set").hide()
  $("#Activity_Chat").show()
}
function Click_Avatar(){
  $("#Activity_Chat").hide()
  $("#Activity_Space").show()
}
function Click_Return_Space(){
  $("#Activity_Space").hide()
  $("#Activity_Chat").show()
}
function Click_PassCard_Upload_Button(){
  $("#PassCard_Upload").click();
}
function PassCard_Upload(){
  files = $("#PassCard_Upload").get(0).files[0];
  if(files){
      if(files.size>0){
        var reader = new FileReader()
        reader.readAsText(files,'utf-8')
        reader.onload = function(){
          if(reader.result != null){
            //？？？？
            
          }
        }
      }
  }
}
function Click_PassCard_LinkChange_Button(){
  var Link = $("#Set_Box_LinkInput").val()
  if(Link == null || Link.length == 0){
    $("#Set_Box_LinkInput").attr("placeholder", "PassCard不能为空")
  }else{
    //？？？？
  }
}
//----------------------------------------------
//功能函数
function Set_ChatRoom_InnerHTML(innerHTML){//强制修改聊天框信息
  innerHTML = 
  document.getElementById('ChatRoom').innerHTML = innerHTML;
}
function Add_ChatMessage(content){//缓动添加聊天消息
  $("#ChatRoom").append(content)
  $('#ChatRoom').animate({
    scrollTop: El_ChatRoom.scrollHeight
  }, 500);
}
function Add_SpaceLog(content){//添加动态(无需缓动)
  $("#Space_LogBox").before(content)
  // document.getElementById('Space_ContentBox').scrollTop = "0px"
}
function Set_Avatar(AvatarPatch){//设置头像 Link or Base64
  // 推荐640*640
  $("#Chat_Avatar").attr("src", AvatarPatch)
  $("#Space_Avatar").attr("src", AvatarPatch)
}
function Set_UserName(Name){//设置用户名
  $("#Chat_Header_Name").text(Name)
  $("#Space_Name").text(Name)
}
function Set_SpaceIntroduction(Introduction){//设置用户简介
  $("#Space_Introduction").text(Introduction)
}
function Set_ChatOpinion(op1,op2){//设置选项内容 并显示选项框
  SetOpinionState(1)
  document.getElementById("OpinionA").innerHTML = op1
  document.getElementById("OpinionB").innerHTML = op2
}
function Set_OpinionState(type){//设置选项框状态
  type = parseInt(type)
  if(type == 0){//隐藏
    document.getElementById("ChatRoom").style.height="calc(100% - 120px)"//calc(100% - 200px - 120px)
    $('#Chat_OpinionBox').animate({
      height: "0px"
    }, 200);
  }
  if(type == 1){//显示
    document.getElementById("ChatRoom").style.height="calc(100% - 200px - 120px)"//calc(100% - 200px - 120px)
    $('#Chat_OpinionBox').animate({
      height: "200px"
    }, 500);
  }
  if(type == 3){//强制隐藏
    document.getElementById("ChatRoom").style.height="calc(100% - 120px)"//calc(100% - 200px - 120px)
    document.getElementById("Chat_OpinionBox").style.height="0px"//200px
  }
  $('#ChatRoom').animate({
    scrollTop: El_ChatRoom.scrollHeight
  }, 500);
}
//------------------