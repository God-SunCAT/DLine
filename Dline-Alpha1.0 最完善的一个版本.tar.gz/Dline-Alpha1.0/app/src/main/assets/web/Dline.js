
var btn_MessageState,btn_MessageMode
btn_MessageState = false;
btn_MessageMode = false;
T_Add_ChatMessage(T_GenerateChatMessage(1,"艾希亚帝国和神圣不可分割之联合王国据说已经开始第六十七轮谈判了。",T_GetMessageData_NOW()))
T_Add_ChatMessage(T_GenerateChatMessage(2,"艾希亚帝国和神圣不可分割之联合王国据说已经开始第六十七轮谈判了。",T_GetMessageData_NOW()))
T_Set_ChatOpinion("谁让神圣联合王国的人非要把格兰迪说成他们的地盘。谁让神圣联合王国的人非要把格兰迪说成他们的地盘。","帝国和神圣联合王国已经越缠越紧了。")
// Dline_Android.ReSetStory("1")
//----------------------------------------------
Set_OpinionState(3)
$("#Activity_Set").hide()
$("#Activity_Space").hide()
$("#MaskBox_Dictionary").hide()
// $("#Activity_Chat").hide()
//----------------------------------------------
//事件函数
function Click_MaskBox(){
  $("#MaskBox_Dictionary").hide()
}
function Click_DictionaryTip(content){
  // <a onclick="Click_DictionaryTip('title[&&&Tip&&&]content')">title</a>
  // [$$$Dictionary][Title]词典标题[Content]词典内容[ShowContent]显示内容[Dictionary$$$]
  listC = content.split("[&&&Tip&&&]")
  if(listC.length == 2){
    document.getElementById("Dictionary_Title").innerHTML = listC[0]
    document.getElementById("Dictionary_Content").innerHTML = listC[1]
  }else{
    document.getElementById("Dictionary_Title").innerHTML = "Error"
    document.getElementById("Dictionary_Content").innerHTML = "Error"
  }
  $("#MaskBox_Dictionary").show()
}
function Click_OpinionA(){
  Dline_Android.OpinionA_Choose()
  Set_OpinionState(0)
  // Worker1.postMessage([3,1])//选项按下
}
function Click_OpinionB(){
  Set_OpinionState(0)
  Dline_Android.OpinionB_Choose()
  // Worker1.postMessage([3,2])
}
function Click_Menu(){
  $("#Set_Box_LinkInput").val("")
  $("#Set_Box_LinkInput").attr("placeholder", "PassCard")
  $("#Activity_Chat").hide()
  $("#Activity_Set").show()
}
function Click_Return_Set(){
  $("#Activity_Set").hide()
  $("#Activity_Chat").show()
}
function Click_Avatar(){
  $("#Activity_Chat").hide()
  $("#Activity_Space").show()
}
function Click_Return_Space(){
  $("#Activity_Space").hide()
  $("#Activity_Chat").show()
}
function Click_PassCard_Upload_Button(){
  $("#PassCard_Upload").click();
}
function PassCard_Upload(){
  files = $("#PassCard_Upload").get(0).files[0];
  if(files){
      if(files.size>0){
        var reader = new FileReader()
        reader.readAsText(files,'utf-8')
        reader.onload = function(){
          if(reader.result != null){
            Dline_Android.ReSetStory(reader.result)
            $("#Set_Box_LinkInput").val("")
            $("#Set_Box_LinkInput").attr("placeholder", "时空通行证已变更")
          }
        }
      }
  }
}
function Click_PassCard_LinkChange_Button(){
  var Link = $("#Set_Box_LinkInput").val()
  if(Link == null || Link.length == 0){
    $("#Set_Box_LinkInput").attr("placeholder", "PassCard不能为空")
  }else{
    GetStoryFromURL(Link)
  }
}
function Click_Btn_MessageState(){
  var btn = document.getElementById("btn-MessageState")
  var circle = document.getElementById("btn-MessageState-Point")
  var text = document.getElementById("btn-MessageState-Text")

  if(!btn_MessageState){
    btn.style= "background-color: #35393b;"
    circle.style="right: 15px;background-color: #888;box-shadow: 0 0 10px #888;";
    text.style="left: 15px;color: #888;";
    text.innerText="停用消息通知";
  } else {
    btn.style= ""
    circle.style="left: 15px";
    text.style="";
    text.innerText="启用消息通知";
  }
  Dline_Android.ChangeBtnState(1,btn_MessageState)
  btn_MessageState = !btn_MessageState
}
function Click_Btn_MessageMode(){
  var btn = document.getElementById("btn-MessageMode")
  var circle = document.getElementById("btn-MessageMode-Point")
  var text = document.getElementById("btn-MessageMode-Text")

  if(!btn_MessageMode){
    btn.style= "background-color: #35393b;"
    circle.style="right: 15px;background-color: #888;box-shadow: 0 0 10px #888;";
    text.style="left: 15px;color: #888;";
    text.innerText="停用通知模式二";
  } else {
    btn.style= ""
    circle.style="left: 15px";
    text.style="";
    text.innerText="启用通知模式二";
  }
  Dline_Android.ChangeBtnState(2,btn_MessageMode)
  btn_MessageMode = !btn_MessageMode
}
//----------------------------------------------
//功能函数
function ChangeUserState(State){
  State = parseInt(State)
  switch(State){
    case 1:
    $("#Chat_Header_State").text("在线")
    $("#Chat_Header_State").css("color","rgb(62, 114, 252)")
    break
    case 2:
      $("#Chat_Header_State").text("离线")
      $("#Chat_Header_State").css("color","rgb(206,202,195)")
    break
  }
}
function ChangeBtnState(type,State){
  type = parseInt(type)
  switch(type){
    case 1://btn_MessageState
      btn_MessageState = State
      Click_Btn_MessageState()
    break
    case 2://btn_MessageMode
    btn_MessageMode = State
    Click_Btn_MessageMode()
    break
  }
}
function Set_ChatRoom_InnerHTML(innerHTML){//强制修改聊天框信息
  innerHTML = GetTempItemData(innerHTML)
  document.getElementById('ChatRoom').innerHTML = innerHTML;
  $("#ChatRoom").animate({
    scrollTop: document.getElementById('ChatRoom').scrollHeight
  }, { duration: 500, queue: false });
}
function Set_Space_LogBox_InnerHTML(innerHTML){//强制修改动态
  innerHTML = GetTempItemData(innerHTML)
  document.getElementById('Space_LogBox').innerHTML = innerHTML;
}
function Add_ChatMessage(content){//缓动添加聊天消息
  content = GetTempItemData(content)
  $("#ChatRoom").append(content)
  $("#ChatRoom").animate({
    scrollTop: document.getElementById('ChatRoom').scrollHeight
  }, { duration: 500, queue: false });
}
function Add_SpaceLog(content){//添加动态(无需缓动)
  content = GetTempItemData(content)
  $("#Space_LogBox").before(content)
  // document.getElementById('Space_ContentBox').scrollTop = "0px"
}
function Set_Avatar(AvatarPatch){//设置头像 Link or Base64
  AvatarPatch = GetTempItemData(AvatarPatch)
  // 推荐640*640
  $("#Chat_Avatar").attr("src", AvatarPatch)
  $("#Space_Avatar").attr("src", AvatarPatch)
}
function Set_UserName(Name){//设置用户名
  Name = GetTempItemData(Name)
  $("#Chat_Header_Name").text(Name)
  $("#Space_Name").text(Name)
}
function Set_SpaceIntroduction(Introduction){//设置用户简介
  Introduction = GetTempItemData(Introduction)
  $("#Space_Introduction").text(Introduction)
}
function Set_ChatOpinion(op1,op2){//设置选项内容 并显示选项框
  op1 = GetTempItemData(op1)
  op2 = GetTempItemData(op2)
  document.getElementById("OpinionA").innerHTML = op1
  document.getElementById("OpinionB").innerHTML = op2
  Set_OpinionState(1)
}
function Set_OpinionState(type){//设置选项框状态
  type = parseInt(type)
  if(type == 0){//隐藏
    $("#ChatRoom").animate({
      height: $("#ChatBox").height() - 120 //'calc(100% - 120px)'
    }, { duration: 200, queue: false });
    $("#Chat_OpinionBox").animate({
      height: '0px'
    }, { duration: 200, queue: false });
  }
  if(type == 1){//显示
    $("#ChatRoom").animate({
      height: $("#ChatBox").height() - 200 - 120//'calc(100% - 200px - 120px)'
    }, { duration: 500, queue: false });
    $("#Chat_OpinionBox").animate({
      height: '200px'
    }, { duration: 500, queue: false });
  }
  if(type == 3){//强制隐藏
    document.getElementById("ChatRoom").style.height="calc(100% - 120px)"//calc(100% - 200px - 120px)
    document.getElementById("Chat_OpinionBox").style.height="0px"//200px
  }
  $("#ChatRoom").animate({
    scrollTop: document.getElementById('ChatRoom').scrollHeight
  }, { duration: 300, queue: false });
}
function ReturnChatPage(){
  if($("#Activity_Chat").is(":visible") == false){
    $("#Activity_Set").hide()
    $("#Activity_Space").hide()
    $("#Activity_Chat").show()
    return(true);
  }
  return(false);
}
//-----------------
//私有方法
function GetStoryFromURL(file_url) {
  let xhr = new XMLHttpRequest();
  xhr.open("get", file_url, true);
  xhr.responseType = "blob";
  xhr.onload = function () {
    if (this.status == 200) {
      const reader = new FileReader()
      reader.onload = function () {
          if(reader.result != null){
              Dline_Android.ReSetStory(reader.result)
              $("#Set_Box_LinkInput").val("")
              $("#Set_Box_LinkInput").attr("placeholder", "时空通行证已变更")
          }
      }
      reader.readAsText(this.response)
    }else{
      $("#Set_Box_LinkInput").val("")
      $("#Set_Box_LinkInput").attr("placeholder", "时空通行证错误")
    }
  };
  try {
    xhr.send()
  } catch (error) {
    $("#Set_Box_LinkInput").val("")
    $("#Set_Box_LinkInput").attr("placeholder", "时空通行证错误")
  }
}
//------------------
//app提供
function GetTempItemData(Key){
  return(Dline_Android.TempItem_GetItem(Key))
}
function SetTempItemData(Key,Value){
  Dline_Android.TempItem_SetItem(Key,Value.toString())
}
//-----------------
function T_Add_ChatMessage(content){//缓动添加聊天消息
  $("#ChatRoom").append(content)
  $("#ChatRoom").animate({
    scrollTop: document.getElementById('ChatRoom').scrollHeight
  }, { duration: 500, queue: false });
}
function T_Set_ChatOpinion(op1,op2){//设置选项内容 并显示选项框
  document.getElementById("OpinionA").innerHTML = op1
  document.getElementById("OpinionB").innerHTML = op2
  Set_OpinionState(1)
}
function T_GetMessageData_NOW(){
  var date = new Date()
  var year = date.getFullYear()    //  返回的是年份
  var month = date.getMonth() + 1  //  返回的月份上个月的月份，记得+1才是当月
  var dates = date.getDate()       //  返回的是几号
  var day = date.getDay()          //  周一返回的是1，周六是6，但是周日是0
  var hours = date.getHours()
  var minutes = date.getMinutes()
  if(minutes<9){minutes = "0" + minutes}
  return(month + "/" + dates + " " + hours + ":" + minutes)
}
function T_GenerateChatMessage(type,content,send_date){
  var message
  if(type == null || type == 0){type = 1}

  switch(type){
      case 1://other
      message = `
      <div class="message_row other-message">
      <div class="message-content">
      <div class="message-text" id="ChatMessageID">` + content + `</div>
      <div class="message-time">` + send_date + `</div>
      </div>
      </div>
      `
      break
      case 2: //self
      message = `
      <div class="message_row you-message">
      <div class="message-content">
      <div class="message-text" id="ChatMessageID">` + content + `</div>
      <div class="message-time">` + send_date + `</div>
      </div>
      </div>
      `
      break
      case 3://other photo
      message = `
      <div class="message_row other-message">
      <div class="message-content">
      <img class="me_photo" src="` + content + `" alt="" id="ChatMessageID">
      <div class="message-time">` + send_date + `</div>
      </div>
      </div>
      `
      break
      case 4://self photo
      message = `
      <div class="message_row you-message">
      <div class="message-content">
      <img class="me_photo" src="` + content + `" alt="" id="ChatMessageID">
      <div class="message-time">` + send_date + `</div>
      </div>
      </div>
      `
      break
      case 5://动态

      break
      case 6://System
      message = `
      <div class="System-message-text" id="ChatMessageID">` + content + `</div>
      `
      break
  }
  return(message)
}