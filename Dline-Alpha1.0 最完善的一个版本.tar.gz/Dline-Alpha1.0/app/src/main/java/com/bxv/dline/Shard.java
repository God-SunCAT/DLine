package com.bxv.dline;

import android.util.Log;

import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Shard {
    public static String CreateMessageString(int Type,String Content,Long Send_date){
        String message;
        String Date = "";
        if(Type != 6){
            Date date = new Date(Send_date);
//        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            DateFormat dateFormat = new SimpleDateFormat("MM/dd hh:mm");
            Date = dateFormat.format(date);
        }
        // <a onclick="Click_DictionaryTip('title[&&&Tip&&&]content')">title</a>
        // [$$$Dictionary][Title]词典标题[Content]词典内容[ShowContent]显示内容[Dictionary$$$]
        Content = Content.replace("[$$$Dictionary][Title]","<a onclick=\"Click_DictionaryTip('");
        Content = Content.replace("[Content]","[&&&Tip&&&]");
        Content = Content.replace("[ShowContent]","')\">");
        Content = Content.replace("[Dictionary$$$]","</a>");
        // 词典替换
        if(Type == 0){Type = 1;}
        switch (Type){
            case 1://other
                message = "          <div class=\"message_row other-message\">\n" +
                        "          <div class=\"message-content\">\n" +
                        "          <div class=\"message-text\" id=\"ChatMessageID\">" + Content + "</div>\n" +
                        "          <div class=\"message-time\">" + Date + "</div>\n" +
                        "          </div>\n" +
                        "          </div>";
                break;
            case 2://self
                message = "          <div class=\"message_row you-message\">\n" +
                        "          <div class=\"message-content\">\n" +
                        "          <div class=\"message-text\" id=\"ChatMessageID\">" + Content + "</div>\n" +
                        "          <div class=\"message-time\">" + Date + "</div>\n" +
                        "          </div>\n" +
                        "          </div>";
                break;
            case 3://other photo
                message = "          <div class=\"message_row other-message\">\n" +
                        "          <div class=\"message-content\">\n" +
                        "          <img class=\"me_photo\" src=\"" + Content + "\" alt=\"\" id=\"ChatMessageID\">\n" +
                        "          <div class=\"message-time\">" + Date + "</div>\n" +
                        "          </div>\n" +
                        "          </div>";
                break;
            case 4://self photo
                message = "          <div class=\"message_row you-message\">\n" +
                        "          <div class=\"message-content\">\n" +
                        "          <img class=\"me_photo\" src=\"" + Content + "\" alt=\"\" id=\"ChatMessageID\">\n" +
                        "          <div class=\"message-time\">" + Date + "</div>\n" +
                        "          </div>\n" +
                        "          </div>";
                break;
            case 5://动态
                String imgLink = null;
                int index = Content.indexOf("[img]");
                if(index != -1){
                    imgLink = Content.substring(index+5);
                    Content = Content.substring(0,index);
                }
                message = "          <div class=\"Space_Log\">\n" +
                        "          <div class=\"Content\">" + Content + "</div>";
                if(imgLink != null && imgLink != ""){
                    message += "<img src=\"" + imgLink + "\">";
                }
                message += "          <div class=\"date\"> — " + Date + "</div>\n" +
                        "          </div>\n" +
                        "          <hr>";
                break;
            case 6://System
                message = "<div class=\"System-message-text\" id=\"ChatMessageID\">" + Content + "</div>";
                break;
            default:
                message = "<div class=\"System-message-text\" id=\"ChatMessageID\">Error:Message</div>";
                break;
        }
        return message;
    }
}
