package com.bxv.dline;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.AbstractWindowedCursor;
import android.database.Cursor;
import android.database.CursorWindow;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.util.Random;

public class SQLite {
    public SQLiteDatabase db;
    public void InitializationSqlite() {
        db = DatabaseManager.getInstance().openDatabase();
    }
    public SQLiteDatabase GetDB(){
        return db;
    }
    public void SetItem(String Key,String Value){
        ContentValues contentValues = new ContentValues();
        contentValues.put("Key",Key);
        contentValues.put("Value",Value);
        db.replace("Item",null,contentValues);
    }
    @RequiresApi(api = Build.VERSION_CODES.P)
    @SuppressLint("Range")
    public String GetItem(String Key){
        String value;
        Cursor cursor = db.rawQuery("Select * From Item Where `Key` = ?",new String[]{Key});
        CursorWindow cw = new CursorWindow("DLine_SqliteCw", 12000000);
        AbstractWindowedCursor ac = (AbstractWindowedCursor) cursor;
        ac.setWindow(cw);
        if(cursor.getCount() != 0){
            if(cursor.moveToNext()){
                value = cursor.getString(cursor.getColumnIndex("Value"));
            }else{
                value = "";
            }
        }else{
            value = "";
        }
        cursor.close();
        return value;
    }
    public void SetTempItem(String Key,String Value){
        ContentValues contentValues = new ContentValues();
        contentValues.put("Key",Key);
        contentValues.put("Value",Value);
        db.replace("TempItem",null,contentValues);
    }
    @SuppressLint("Range")
    public String GetTempItem(String Key){//Get and Delete
        String value = "";
        Cursor cursor = db.rawQuery("Select * From TempItem Where `Key` = ?",new String[]{Key});
        if(cursor.getCount() != 0) {
            if (cursor.moveToNext()) {
                value = cursor.getString(cursor.getColumnIndex("Value"));
                db.delete("TempItem", "`key` = ?", new String[]{Key});
            }
        }
        cursor.close();
        return value;
    }
    public void AddChatHistory(int Node_ID,String Content,long Send_Date,int Message_Type,int Class){
        ContentValues contentValues = new ContentValues();
        contentValues.put("Node_ID",Node_ID);
        contentValues.put("Content",Content);
        contentValues.put("Send_Date",Send_Date);
        contentValues.put("Message_Type",Message_Type);
        contentValues.put("Class",Class);
        db.replace("ChatHistory",null,contentValues);
    }
    public String CreateTempItemName(){
        return(getRandomString2(32) + "_" + String.valueOf(System.currentTimeMillis()));
    }

    public static String getRandomString2(int length){
        Random random=new Random();
        StringBuffer sb=new StringBuffer();
        for(int i=0;i<length;i++){
            int number=random.nextInt(3);
            long result=0;
            switch(number){
                case 0:
                    result=Math.round(Math.random()*25+65);
                    sb.append(String.valueOf((char)result));
                    break;
                case 1:
                    result=Math.round(Math.random()*25+97);
                    sb.append(String.valueOf((char)result));
                    break;
                case 2:
                    sb.append(String.valueOf(new Random().nextInt(10)));
                    break;
            }


        }
        return sb.toString();
    }
}
