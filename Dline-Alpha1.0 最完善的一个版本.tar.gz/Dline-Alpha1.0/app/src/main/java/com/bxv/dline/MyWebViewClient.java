package com.bxv.dline;

import static java.lang.Thread.sleep;

import android.content.Intent;
import android.net.Uri;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;

class MyWebViewClient extends WebViewClient {
    public IAidlInterface_Service MessageDealService_proxy;
    public ImageView Load_ImageView;
    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        String hostname;
        //HOSTNAME
        hostname = "example.com";
        Uri uri = Uri.parse(url);
        if (url.startsWith("file:") || uri.getHost() != null && uri.getHost().endsWith(hostname)) {
            return false;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        view.getContext().startActivity(intent);
        return true;
    }
    public void onPageFinished(WebView view, String url) {
        super.onPageFinished(view, url);
        try {
            MessageDealService_proxy.Notice_DealStart();
            MessageDealService_proxy.Initialization_Dline_Html();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
//        view.evaluateJavascript("javascript:Add_ChatMessage('16B203d8u0IWsZWt5Br2lK9jKvD7E5l3_1661088182620')", new ValueCallback<String>() {
//            @Override
//            public void onReceiveValue(String value) {
//            }
//        });
        //加载完后操作
    }
}