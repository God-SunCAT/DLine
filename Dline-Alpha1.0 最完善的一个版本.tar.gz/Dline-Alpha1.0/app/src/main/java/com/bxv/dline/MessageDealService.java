package com.bxv.dline;

import static java.lang.Thread.*;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.PrivilegedAction;
import java.util.List;


public class MessageDealService extends Service {
    SQLite mSQLite = new SQLite();
    NotifyCallBack mNotifyCallBack;
    StoryRead mStory = new StoryRead();
    boolean BindState=false;
    int WebHistoryID = 0;
    boolean DealMessage = false;
    boolean Add_run_state = false;
    boolean Updata_Story = false;
    boolean ActivityIsFront = false;
    boolean UseMessageNotice = false;
    boolean UseMessageMode2 = false;
    private String[] Op;
    /** 标识服务如果被杀死之后的行为 */
    int mStartMode;
    /** 绑定的客户端接口 */
//    IBinder mBinder;
    private MyBinder mBinder = new MyBinder();
    // 继承的 IMyAidlInterface.Stub，而不是 IMyAidlInterface
    public class MyBinder extends IAidlInterface_Service.Stub {
        @RequiresApi(api = Build.VERSION_CODES.P)
        @Override
        public void SetNotifyCallBack(NotifyCallBack TNotifyCallBack) throws RemoteException {
            mNotifyCallBack = TNotifyCallBack;
            mStory.SetWebCallBack(mNotifyCallBack);
            BindState=true;
            mStory.SetStory(mSQLite.GetItem("Story"));
        }
        @SuppressLint("Range")
        public void Initialization_Dline_Html(){
            String data = "";
            String SpaceData = "";
            int i = 0;
            Cursor cursor = mSQLite.GetDB().rawQuery("Select * From ChatHistory Where `ID` <= ?", new String[]{String.valueOf(WebHistoryID)});
            if (cursor.getCount() != 0) {
                while (cursor.moveToNext()) {
                    i++;
                    if(cursor.getInt(cursor.getColumnIndex("Message_Type")) != 5){
                        data += Shard.CreateMessageString(cursor.getInt(cursor.getColumnIndex("Message_Type")), cursor.getString(cursor.getColumnIndex("Content")), cursor.getLong(cursor.getColumnIndex("Send_Date")));
                    }else{
                        SpaceData += Shard.CreateMessageString(cursor.getInt(cursor.getColumnIndex("Message_Type")), cursor.getString(cursor.getColumnIndex("Content")), cursor.getLong(cursor.getColumnIndex("Send_Date")));
                    }
                    if(cursor.getCount() == i){
                        int Wat = mStory.GetWaitTime(cursor.getColumnIndex("Node_ID") + 1);
                        try {
                            if(Wat != -1 && Wat < 180000){
                                mNotifyCallBack.Web_ChangeUserState(1);
                            }else{
                                mNotifyCallBack.Web_ChangeUserState(2);
                            }
                        } catch (RemoteException e) {
                            e.printStackTrace();
                        }
                        if(cursor.getInt(cursor.getColumnIndex("Class")) == 1){
                            String[] op = mStory.GetOpinion(cursor.getInt(cursor.getColumnIndex("Node_ID")));
                            Op = op;
                            try {
                                mNotifyCallBack.Web_Set_ChatOpinion(op[0],op[1]);
                            } catch (RemoteException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
                try {
                    String TName = mSQLite.CreateTempItemName();
                    mSQLite.SetTempItem(TName,data);
                    mNotifyCallBack.Web_Set_ChatRoom_InnerHTML(TName);
                    TName = mSQLite.CreateTempItemName();
                    mSQLite.SetTempItem(TName,SpaceData);
                    mNotifyCallBack.Web_Set_Space_LogBox_InnerHTML(TName);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
            try {
                if(mStory.sUserName != ""){
                    mNotifyCallBack.Web_Set_UserName(mStory.sUserName);
                }
                if(mStory.sUserAvatar != ""){
                    String TName = mSQLite.CreateTempItemName();
                    mSQLite.SetTempItem(TName,mStory.sUserAvatar);
                    mNotifyCallBack.Web_Set_Avatar_DcLite(TName);
//                    mNotifyCallBack.Web_Set_Avatar(mStory.sUserAvatar);
                }
                if(mStory.sUserIntroduction != ""){
                    mNotifyCallBack.Web_Set_SpaceIntroduction(mStory.sUserIntroduction);
                }
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            try {
                mNotifyCallBack.Activity_LoadVieHide();
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
        @RequiresApi(api = Build.VERSION_CODES.P)
        public void Notice_DealStart(){
//            if(mSQLite.GetItem("Story") == ""){
//                try {
//                    mNotifyCallBack.Web_Add_ChatMessage(Shard.CreateMessageString(6, "未检测到通行证", 0));
//                } catch (RemoteException e) {
//                    e.printStackTrace();
//                }
//            }
            if(mSQLite.GetItem("Story") == ""){
                ReSetStory(readStringFromAssets());
            }
            try {
                mNotifyCallBack.Web_ChangeBtnState(1, Boolean.parseBoolean(mSQLite.GetItem("btn_MessageState")));
                mNotifyCallBack.Web_ChangeBtnState(2, Boolean.parseBoolean(mSQLite.GetItem("btn_MessageMode")));
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            Update_MessageNoticeMode();

        }
        public void OpinionA_Choose(){
            mSQLite.AddChatHistory(0,Op[0],System.currentTimeMillis(),2,0);
            MessageDeal(Integer.parseInt(Op[2]),System.currentTimeMillis());
        }
        public void OpinionB_Choose(){
            mSQLite.AddChatHistory(0,Op[1],System.currentTimeMillis(),2,0);
            MessageDeal(Integer.parseInt(Op[3]),System.currentTimeMillis());
        }
        public void ReSetStory_BySQLite(String St){
            ReSetStory(mSQLite.GetTempItem(St));
        }
        public void ReSetStory(String St){
//            St = readStringFromAssets(); //Debug锁定剧本
            Updata_Story = true;
            mSQLite.SetItem("Story",St);
            mStory.SetStory(St);
            WebHistoryID = 0;
            mSQLite.SetItem("WebHistoryID", String.valueOf(0));
            mSQLite.db.execSQL("DELETE FROM ChatHistory");
            Op = new String[]{};
            Updata_Story = false;
            try {
                mNotifyCallBack.Web_Set_OpinionState(3);
                mNotifyCallBack.Web_Set_ChatRoom_InnerHTML("");
                mNotifyCallBack.Web_Set_Space_LogBox_InnerHTML("");
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            MessageDeal(1,System.currentTimeMillis());
            try {
                if(mStory.sUserName != ""){
                    mNotifyCallBack.Web_Set_UserName(mStory.sUserName);
                }
                if(mStory.sUserAvatar != ""){
                    String TName = mSQLite.CreateTempItemName();
                    mSQLite.SetTempItem(TName,mStory.sUserAvatar);
                    mNotifyCallBack.Web_Set_Avatar_DcLite(TName);
                }
                if(mStory.sUserIntroduction != ""){
                    mNotifyCallBack.Web_Set_SpaceIntroduction(mStory.sUserIntroduction);
                }
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
        public void SetActivityFrontState(boolean State){
            ActivityIsFront = State;
        }
        @RequiresApi(api = Build.VERSION_CODES.P)
        public void Update_MessageNoticeMode(){
            UseMessageNotice = Boolean.parseBoolean(mSQLite.GetItem("btn_MessageState"));
            UseMessageMode2 = Boolean.parseBoolean(mSQLite.GetItem("btn_MessageMode"));
        }
    }
    private String readStringFromAssets() {
        //通过设备管理对象 获取Asset的资源路径
        AssetManager assetManager = this.getApplicationContext().getAssets();

        InputStream inputStream = null;
        InputStreamReader isr = null;
        BufferedReader br = null;

        StringBuffer sb =  new StringBuffer();
        try{
            inputStream = assetManager.open("web/src/Miko_Heritage_S2.json");
            isr = new InputStreamReader(inputStream);
            br = new BufferedReader(isr);

            sb.append(br.readLine());
            String line = null;
            while((line = br.readLine()) != null){
                sb.append("\n" + line);
            }

            br.close();
            isr.close();
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
                if (isr != null) {
                    isr.close();
                }
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }
    @SuppressLint("Range")
    private void MessageAdd(){
        // 5 == Space
            Cursor cursor = mSQLite.db.rawQuery("Select * From ChatHistory Where `Send_Date` <= ? and `ID` > ?", new String[]{String.valueOf(System.currentTimeMillis()), String.valueOf(WebHistoryID)});
            if (cursor.getCount() != 0) {
                int i = 0;
                while (cursor.moveToNext()) {
                    i++;
                    String data = Shard.CreateMessageString(cursor.getInt(cursor.getColumnIndex("Message_Type")), cursor.getString(cursor.getColumnIndex("Content")), cursor.getLong(cursor.getColumnIndex("Send_Date")));
                    WebHistoryID = cursor.getInt(cursor.getColumnIndex("ID"));
                    if (BindState) {
                        int Wat = mStory.GetWaitTime(cursor.getColumnIndex("Node_ID") + 1 );
                        try {
                            if(Wat != -1 && Wat < 180000){
                                mNotifyCallBack.Web_ChangeUserState(1);
                            }else{
                                mNotifyCallBack.Web_ChangeUserState(2);
                            }
                        } catch (RemoteException e) {
                            e.printStackTrace();
                        }
                        if(cursor.getInt(cursor.getColumnIndex("Message_Type")) == 5){
                            Log.d("SXV","DT");
                            //动态
                            try {
                                String TName = mSQLite.CreateTempItemName();
                                mSQLite.SetTempItem(TName,data);
                                mNotifyCallBack.Web_Add_SpaceLog(TName);
                            } catch (RemoteException e) {
                                e.printStackTrace();
                            }
                            data = Shard.CreateMessageString(6, "对方发布了一条新动态", Long.valueOf(0));
                            Log.d("SXV",data);
                        }
                        try {
                            mNotifyCallBack.Web_Add_ChatMessage(data);
                        } catch (RemoteException e) {
                            e.printStackTrace();
                        }
                        if(cursor.getInt(cursor.getColumnIndex("Class")) == 1 && cursor.getCount() == i){
                            String[] op = mStory.GetOpinion(cursor.getInt(cursor.getColumnIndex("Node_ID")));
                            Op = op;
                            try {
                                mNotifyCallBack.Web_Set_ChatOpinion(op[0],op[1]);
                            } catch (RemoteException e) {
                                e.printStackTrace();
                            }
                        }
                        if(!ActivityIsFront && UseMessageNotice){
                            SendNotification(mStory.sUserName, cursor.getString(cursor.getColumnIndex("Content")), 8848);
                        }
                    } else {
                        if (UseMessageNotice){
                            SendNotification(mStory.sUserName, cursor.getString(cursor.getColumnIndex("Content")), 8848);
                        }
                    }
                    mSQLite.SetItem("WebHistoryID", String.valueOf(cursor.getInt(cursor.getColumnIndex("ID"))));
                }
            }

    }
    private synchronized void  MessageDeal(int NodeID,long LastTime){
        List<StoryNode> Data = mStory.ReadStoryNode(NodeID);
        StoryNode TSN;
        int Class = 0;
        for(int i =0;i != Data.size();i++){
            TSN = Data.get(i);
            LastTime = LastTime + TSN.WaitTime;//Debug删掉无延迟
            if(TSN.Options_A != null){
                Class = 1;
            }
            mSQLite.AddChatHistory(TSN.Node_ID,TSN.Node_Content,LastTime, TSN.Message_Type, Class);
        }
        DealMessage = false;
    }
    /** 标识是否可以使用onRebind */
    boolean mAllowRebind;
    /** 当服务被创建时调用. */
    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    public void onCreate() {
        initNotificationChannel();
        SendNotification_startForeground("Dline","时空引擎持续运行中");
        CancelNotification(8849);
        DatabaseManager.initializeInstance(new DBHelper(this, "DlineData.db",null,1));
        mSQLite.InitializationSqlite();
        String TID = mSQLite.GetItem("WebHistoryID");
        if(TID == ""){
            WebHistoryID = 0;
        }else{
            WebHistoryID = Integer.parseInt(TID);
        }
        if(WebHistoryID == 0){
            WebHistoryID++;
        }
        if(Add_run_state == false){
            Add_run_state = true;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    while (true){//特喵了个咪的的,线程用不了,只能塞这里
                        if(!Updata_Story){
                            MessageAdd();
                        }
                        try {
                            sleep(500);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }).start();
        }

//        mStory.SetStory(mSQLite.GetItem("Story"));
    }
    /** 调用startService()启动服务时回调 */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return mStartMode;
    }
    /** 通过bindService()绑定到服务的客户端 */
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    /** 通过unbindService()解除所有客户端绑定时调用 */
    @Override
    public boolean onUnbind(Intent intent) {
        BindState=false;
        ActivityIsFront = false;
        mStory.UnSetWebCallBack();
        return mAllowRebind;
    }
    /** 通过bindService()将客户端绑定到服务时调用*/
    @Override
    public void onRebind(Intent intent) {
    }
    /** 服务不再有用且将要被销毁时调用 */
    @Override
    public void onDestroy() {
        super.onDestroy();
        Intent intent= new Intent();
        intent.setComponent(new ComponentName(this,BootBroadCastReceiver.class));
        intent.setAction("restartService");
        MessageDealService.this.sendBroadcast(intent);
        Log.d("BXV","寄!");
//        SendNotification("Miko", "Dline消息通知寄了",8849);
    }
//    http://192.168.1.10:5500/src/五年后再相会By小小飞_Final.json
    //消息推送
    private void initNotificationChannel() {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.O) {
            // 创建一个通知渠道至少需要渠道ID、渠道名称以及重要等级这三个参数
            // 渠道ID可以随便定义，只要保证全局唯一性就可以
            String channelId = "Dline_Chat";
            // 渠道名称是给用户看的，需要能够表达清楚这个渠道的用途
            String channelName = "Dline聊天通知";
            // 重要等级的不同则会决定通知的不同行为，重要等级还可以设置为IMPORTANCE_LOW、IMPORTANCE_MIN，分别对应了更低的通知重要程度。
            int importance = NotificationManager.IMPORTANCE_HIGH;
            createNotificationChannel(channelId, channelName, importance);
//
//            channelId = "subscribe";
//            channelName = "订阅消息";
//            importance = NotificationManager.IMPORTANCE_DEFAULT;
//            createNotificationChannel(channelId, channelName, importance);
        }
    }

    @TargetApi(Build.VERSION_CODES.O)
    private void createNotificationChannel(String channelId, String channelName, int importance) {
        // 创建 channel
        NotificationChannel channel = new NotificationChannel(channelId, channelName, importance);
        // 获取 notificationManager
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        // 注册 channel
        notificationManager.createNotificationChannel(channel);
    }
    private void SendNotification(String Title,String Text,int TID){
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        //第二步：创建
        Notification notification = new NotificationCompat.Builder(this, "Dline_Chat")
                .setContentTitle(Title)
                .setContentText(Text)
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(R.drawable.ic_notification_logo_text)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_logo))
                .setAutoCancel(true)
                .build();
        //第三步：发送
//        notificationManager.cancel(NotificationID);//干掉上一条通知
//        notificationManager.notify(++NotificationID, notification);
        if(TID < 8849){
            notificationManager.cancel(TID);//干掉上一条通知
        }
        notificationManager.notify(TID, notification);
    }
    private void SendNotification_startForeground(String Title,String Text){
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        //第二步：创建
        Notification notification = new NotificationCompat.Builder(this, "Dline_Chat")
                .setContentTitle(Title)
                .setContentText(Text)
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(R.drawable.ic_notification_logo_text)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_logo))
                .setAutoCancel(true)
                .build();
        startForeground(1, notification);
    }
    private void CancelNotification(int TID) {
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        notificationManager.cancel(TID);//干掉上一条通知
    }
    //消息推送


}
