package com.bxv.dline;

public class StoryNode {
    public int Node_ID,Options_A_Jump_ID,Options_B_Jump_ID,WaitTime,Message_Type;
    public String Node_Content,Options_A,Options_B;
}
