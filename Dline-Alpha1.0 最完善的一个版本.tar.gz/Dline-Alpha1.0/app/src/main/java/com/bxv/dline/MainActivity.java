package com.bxv.dline;


import static java.lang.Thread.sleep;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.graphics.BitmapFactory;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebChromeClient;

import android.annotation.TargetApi;
import android.content.Intent;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.os.Build;
import android.content.ClipData;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import java.util.List;

public class MainActivity extends Activity {


    private Intent serviceIntent;
    IAidlInterface_Service MessageDealService_proxy;
    private WebView mWebView;
    private ImageView Load_ImageView;
    MyWebViewClient mWebViewClient = new MyWebViewClient();
    JsInteration  Dline_Android;
    private ValueCallback<Uri> uploadMessage;
    private ValueCallback<Uri[]> uploadMessageAboveL;
    private final static int FILE_CHOOSER_RESULT_CODE = 10000;
    SQLite mSQLite = new SQLite();
    boolean IsFront = false;
    boolean ServiceState = false;
    private long firstTime;
    NotifyCallBack serviceCallback = new NotifyCallBack.Stub() {
        @Override
        public void func() throws RemoteException {

        }
        @Override
        public void Web_Set_ChatRoom_InnerHTML(String innerHTML) throws RemoteException{
//            CallJavaScriptFunction("Set_ChatRoom_InnerHTML",new String[]{innerHTML});
            mWebView.post(new Runnable() {//注意线程,真特喵了个咪
                @Override
                public void run() {
                    mWebView.evaluateJavascript("javascript:Set_ChatRoom_InnerHTML(\""+ innerHTML + "\")", new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                        }
                    });
                }
            });
        }
        @Override
        public void Web_Set_Space_LogBox_InnerHTML(String innerHTML){
//            CallJavaScriptFunction("Set_Space_LogBox_InnerHTML",new String[]{innerHTML});
            mWebView.post(new Runnable() {//注意线程,真特喵了个咪
                @Override
                public void run() {
                    mWebView.evaluateJavascript("javascript:Set_Space_LogBox_InnerHTML(\""+ innerHTML + "\")", new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                        }
                    });
                }
            });
        }
        @Override
        public void Web_Add_ChatMessage(String content){
            CallJavaScriptFunction("Add_ChatMessage",new String[]{content});
        }
        @Override
        public void Web_Add_SpaceLog(String content){
//            CallJavaScriptFunction("Add_SpaceLog",new String[]{content});
            mWebView.post(new Runnable() {//注意线程,真特喵了个咪
                @Override
                public void run() {
                    mWebView.evaluateJavascript("javascript:Add_SpaceLog(\""+ content + "\")", new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                        }
                    });
                }
            });
        }
        @Override
        public void Web_Set_Avatar(String AvatarPatch){
            CallJavaScriptFunction("Set_Avatar",new String[]{AvatarPatch});
        }
        @Override
        public void Web_Set_Avatar_DcLite(String AvatarPatch){
            Web_Set_Avatar(mSQLite.GetTempItem(AvatarPatch));//咱也不知道怎么回事,直接调用JS会无效
        }
        @Override
        public void Web_Set_UserName(String Name){
            CallJavaScriptFunction("Set_UserName",new String[]{Name});
        }
        @Override
        public void Web_Set_SpaceIntroduction(String Introduction){
            CallJavaScriptFunction("Set_SpaceIntroduction",new String[]{Introduction});
        }
        @Override
        public void Web_Set_ChatOpinion(String op1,String op2){
            CallJavaScriptFunction("Set_ChatOpinion",new String[]{op1,op2});
        }
        public void Web_Set_OpinionState(int type){
            mWebView.post(new Runnable() {//注意线程,真特喵了个咪
                @Override
                public void run() {
                    mWebView.evaluateJavascript("javascript:Set_OpinionState(" + String.valueOf(type) + ")", new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                        }
                    });
                }
            });
        }
        public void Web_ChangeBtnState(int type,boolean State){
            mWebView.post(new Runnable() {//注意线程,真特喵了个咪
                @Override
                public void run() {
                    mWebView.evaluateJavascript("javascript:ChangeBtnState("+ String.valueOf(type) + "," + String.valueOf(State) + ")", new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                        }
                    });
                }
            });
        }
        public void Web_ChangeUserState(int State){
            mWebView.post(new Runnable() {//注意线程,真特喵了个咪
                @Override
                public void run() {
                    mWebView.evaluateJavascript("javascript:ChangeUserState("+ String.valueOf(State) + ")", new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                        }
                    });
                }
            });
        }
        public void Activity_LoadVieHide(){
//            for(int i = 0;i != 10;i++){
//                Load_ImageView.getBackground().setAlpha(255 - 25*i);
//                try {
//                    sleep(100);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//            }
            Load_ImageView.setVisibility(View.GONE);
        }
    };
    private void CallJavaScriptFunction(String FunctionName,String[] Parameter){
        int i;
        String TParameter = "";
        String TName;
        for(i = 0;i != Parameter.length;i++){
            TName = mSQLite.CreateTempItemName();
            mSQLite.SetTempItem(TName,Parameter[i]);
            TParameter += "\"" + TName + "\"";
            if(i != Parameter.length - 1){
                TParameter +=",";
            }
        }
        String finalTParameter = TParameter;
        mWebView.post(new Runnable() {//注意线程,真特喵了个咪
            @Override
            public void run() {
                mWebView.evaluateJavascript("javascript:" + FunctionName + "(" + finalTParameter + ")", new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                    }
                });
            }
        });
    }
    ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // 获得代理对象
            MessageDealService_proxy = IAidlInterface_Service.Stub.asInterface(service);
            ServiceState = true;
            try {
                MessageDealService_proxy.SetNotifyCallBack(serviceCallback);
                Dline_Android.Initialization_MessageDealService(MessageDealService_proxy);
                mWebViewClient.MessageDealService_proxy = MessageDealService_proxy;
                mWebView.loadUrl("file:///android_asset/web/Dline.html");
                MessageDealService_proxy.SetActivityFrontState(IsFront);
            } catch (RemoteException e) {
                // 调用远程方法会抛出RemoteException 错误
                e.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            ServiceState = false;
        }
    };

    @Override
    @SuppressLint("SetJavaScriptEnabled")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        mWebView = findViewById(R.id.activity_main_webview);
        Load_ImageView = findViewById(R.id.activity_main_LoadImgView);
        Load_ImageView.setVisibility(View.VISIBLE);
        Load_ImageView.getBackground().setAlpha(255);

        WebSettings webSettings = mWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        // 自适配
        mWebView.setInitialScale(1);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        // storage
        webSettings.setDomStorageEnabled(true);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webSettings.setAppCacheEnabled(true);
        // -------------
        //读取file文件
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        //-------------
        mWebViewClient.Load_ImageView = Load_ImageView;
        mWebView.setWebViewClient(mWebViewClient);
        mWebView.setWebChromeClient(new WebChromeClient() {
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams) {
                uploadMessageAboveL = filePathCallback;
                openFileChooserActivity();
                return true;
            }
        });
        //-------------
        //初始化消息推送
        initNotificationChannel();
        CancelNotification(8848);
        //------------------
        DatabaseManager.initializeInstance(new DBHelper(MainActivity.this, "DlineData.db",null,1));
        mSQLite.InitializationSqlite();
        //------------------
        serviceIntent = new Intent(MainActivity.this, MessageDealService.class);
        if(isServiceExisted(MessageDealService.class.getName()) == false) {//服务
            startService(serviceIntent);
        }
        bindService(serviceIntent,serviceConnection,BIND_AUTO_CREATE);
        // -----------------
        Dline_Android = new JsInteration();
        Dline_Android.Initialization_WebView(mWebView);
        Dline_Android.Initialization_SQLite(mSQLite);
        mWebView.addJavascriptInterface(Dline_Android,"Dline_Android");
        //------------------
    }
    @Override
    public void onResume() {
        IsFront = true;
        if(ServiceState){
            try {
                MessageDealService_proxy.SetActivityFrontState(IsFront);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
        CancelNotification(8848);
        super.onResume();
    }
    @Override
    public void onPause() {
        IsFront = false;
        if(ServiceState){
            try {
                MessageDealService_proxy.SetActivityFrontState(IsFront);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
        super.onPause();
    }
    protected void onDestroy() {
        super.onDestroy();
        unbindService(serviceConnection);
    }
    protected void onStart() {
        super.onStart();
    }
    // -----------------
    //消息推送
    private void initNotificationChannel() {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.O) {
            // 创建一个通知渠道至少需要渠道ID、渠道名称以及重要等级这三个参数
            // 渠道ID可以随便定义，只要保证全局唯一性就可以
            String channelId = "Dline_Chat";
            // 渠道名称是给用户看的，需要能够表达清楚这个渠道的用途
            String channelName = "Dline聊天通知";
            // 重要等级的不同则会决定通知的不同行为，重要等级还可以设置为IMPORTANCE_LOW、IMPORTANCE_MIN，分别对应了更低的通知重要程度。
            int importance = NotificationManager.IMPORTANCE_HIGH;
            createNotificationChannel(channelId, channelName, importance);
//
//            channelId = "subscribe";
//            channelName = "订阅消息";
//            importance = NotificationManager.IMPORTANCE_DEFAULT;
//            createNotificationChannel(channelId, channelName, importance);
        }
    }
    @TargetApi(Build.VERSION_CODES.O)
    private void createNotificationChannel(String channelId, String channelName, int importance) {
        // 创建 channel
        NotificationChannel channel = new NotificationChannel(channelId, channelName, importance);
        // 获取 notificationManager
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        // 注册 channel
        notificationManager.createNotificationChannel(channel);
    }
    private void SendNotification(String Title,String Text,int TID){
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        //第二步：创建
        Notification notification = new NotificationCompat.Builder(this, "Dline_Chat")
                .setContentTitle(Title)
                .setContentText(Text)
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(R.drawable.ic_notification_logo_text)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_logo))
                .setAutoCancel(true)
                .build();
        //第三步：发送
//        notificationManager.cancel(NotificationID);//干掉上一条通知
//        notificationManager.notify(++NotificationID, notification);
        if(TID < 8849){
            notificationManager.cancel(TID);//干掉上一条通知
        }
        notificationManager.notify(TID, notification);
    }
    private void CancelNotification(int TID) {
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        notificationManager.cancel(TID);//干掉上一条通知
    }
    //消息推送
    //回调方法触发本地选择文件
    private void openFileChooserActivity() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
//        i.setType("image/*");//图片上传
//        i.setType("file/*");//文件上传
        i.setType("*/*");//文件上传
        startActivityForResult(Intent.createChooser(i, "Image Chooser"), FILE_CHOOSER_RESULT_CODE);
    }
    //选择文件后处理
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_RESULT_CODE) {
            if (null == uploadMessage && null == uploadMessageAboveL) return;
            Uri result = data == null || resultCode != RESULT_OK ? null : data.getData();
            // Uri result = (((data == null) || (resultCode != RESULT_OK)) ? null : data.getData());
            if (uploadMessageAboveL != null) {
                onActivityResultAboveL(requestCode, resultCode, data);
            } else if (uploadMessage != null) {
                uploadMessage.onReceiveValue(result);
                uploadMessage = null;
            }
        } else {
            //这里uploadMessage跟uploadMessageAboveL在不同系统版本下分别持有了
            //WebView对象，在用户取消文件选择器的情况下，需给onReceiveValue传null返回值
            //否则WebView在未收到返回值的情况下，无法进行任何操作，文件选择器会失效
            if (uploadMessage != null) {
                uploadMessage.onReceiveValue(null);
                uploadMessage = null;
            } else if (uploadMessageAboveL != null) {
                uploadMessageAboveL.onReceiveValue(null);
                uploadMessageAboveL = null;
            }
        }
    }
    //选择内容回调到Html页面
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private void onActivityResultAboveL(int requestCode, int resultCode, Intent intent) {
        if (requestCode != FILE_CHOOSER_RESULT_CODE || uploadMessageAboveL == null)
            return;
        Uri[] results = null;
        if (resultCode == Activity.RESULT_OK) {
            if (intent != null) {
                String dataString = intent.getDataString();
                ClipData clipData = intent.getClipData();
                if (clipData != null) {
                    results = new Uri[clipData.getItemCount()];
                    for (int i = 0; i < clipData.getItemCount(); i++) {
                        ClipData.Item item = clipData.getItemAt(i);
                        results[i] = item.getUri();
                    }
                }
                if (dataString != null)
                    results = new Uri[]{Uri.parse(dataString)};
            }
        }
        uploadMessageAboveL.onReceiveValue(results);
        uploadMessageAboveL = null;
    }

    public boolean isServiceExisted(String className) {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> serviceList = am.getRunningServices(Integer.MAX_VALUE);
        int myUid = android.os.Process.myUid();
        for (ActivityManager.RunningServiceInfo runningServiceInfo : serviceList) {
            if (runningServiceInfo.uid == myUid && runningServiceInfo.service.getClassName().equals(className)) {
                return true;
            }
        }
        return false;
    }


    @Override
    public void onBackPressed() {
        mWebView.post(new Runnable() {//注意线程,真特喵了个咪
            @Override
            public void run() {
                mWebView.evaluateJavascript("javascript:ReturnChatPage()", new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        if(!Boolean.parseBoolean(value)){
                            long secondTime = System.currentTimeMillis();
                            if (secondTime - firstTime > 2000) {
                                Toast.makeText(MainActivity.this, "再按一次退出程序", Toast.LENGTH_SHORT).show();
                                firstTime = secondTime;
                            } else {
//                                super.onBackPressed();
                                System.exit(0);
                            }
                        }
                    }
                });
            }
        });
//        if(mWebView.canGoBack()) {
//            mWebView.goBack();
//        } else {
//            super.onBackPressed();
//        }
    }
}


