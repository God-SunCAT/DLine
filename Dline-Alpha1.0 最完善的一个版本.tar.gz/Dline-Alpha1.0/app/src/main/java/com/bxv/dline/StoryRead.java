package com.bxv.dline;

import android.os.RemoteException;
import android.util.Log;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.List;

public class StoryRead {
    NotifyCallBack mNotifyCallBack;
    boolean CB_State = false;
    boolean ST_State = false;
    public String sUserName = "Unknown",sUserAvatar = "",sUserIntroduction = "";
    ObjectMapper mapper = new ObjectMapper();
    JsonNode Story;
    public void SetWebCallBack(NotifyCallBack LNotifyCallBack){
        mNotifyCallBack = LNotifyCallBack;
        CB_State = true;
    }
    public void UnSetWebCallBack(){
        CB_State = false;
    }
    public void SetStory(String TStory){
        JsonNode node,Tnode;
        sUserName = "Unknown";
        sUserAvatar = "./img/Avatar.jpg";
        sUserIntroduction = "";
        try {
            node = mapper.readTree(TStory);
            if(!node.has("Info")){
                AddMessage("读取用户信息错误");
            }else if(!node.get("Info").has(0)){
                AddMessage("读取用户信息错误");
            }else {
                Tnode = mapper.readTree(node.get("Info").get(0).toString());
                if(Tnode.has("UserAvatar")){
                    sUserAvatar = Tnode.get("UserAvatar").asText();
                }
                if(Tnode.has("UserName")){
                    sUserName = Tnode.get("UserName").asText();
                }
                if(Tnode.has("UserIntroduction")){
                    sUserIntroduction = Tnode.get("UserIntroduction").asText();
                }
            }
            if(!node.has("RECORDS")){
                ST_State = false;
                AddMessage("时空通行证错误");
            }else{
                Story =  mapper.readTree(node.get("RECORDS").toString());
                ST_State = true;
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }
    public List<StoryNode> ReadStoryNode(int NodeID){
        List<StoryNode> result = new ArrayList<StoryNode>();
        StoryNode TSN;
        NodeID -= 1;
        JsonNode Tnode;
        if(!ST_State){
            return (result);
        }
        if(Story.size() < NodeID){
            return result;
        }
        boolean ok = false;
        try{
            while (!ok){
                if(Story.has(NodeID)){
                    TSN = new StoryNode();
                    TSN.Node_ID = NodeID+1;
                    Tnode = mapper.readTree(Story.get(NodeID).toString());
                    if(Tnode.has("Node_Content")){
                        TSN.Node_Content = Tnode.get("Node_Content").asText();
                    }else{
                        TSN.Node_Content = "";
                    }
                    if(Tnode.has("Options_A")){
                        TSN.Options_A = Tnode.get("Options_A").asText();
                    }else{
                        TSN.Options_A = null;
                    }
                    if(Tnode.has("Options_B")){
                        TSN.Options_B = Tnode.get("Options_B").asText();
                    }else{
                        TSN.Options_B = null;
                    }
                    if(Tnode.has("Options_A_Jump_ID")){
                        TSN.Options_A_Jump_ID = Tnode.get("Options_A_Jump_ID").asInt();
                    }else{
                        TSN.Options_A_Jump_ID = 0;
                    }
                    if(Tnode.has("Options_B_Jump_ID")){
                        TSN.Options_B_Jump_ID = Tnode.get("Options_B_Jump_ID").asInt();
                    }else{
                        TSN.Options_B_Jump_ID = 0;
                    }
                    if(Tnode.has("WaitTime")){
                        TSN.WaitTime = Tnode.get("WaitTime").asInt();
                    }else{
                        TSN.WaitTime = 0;
                    }
                    if(Tnode.has("Message_Type")){
                        TSN.Message_Type = Tnode.get("Message_Type").asInt();
                    }else{
                        TSN.Message_Type = 1;
                    }
                    if(TSN.Message_Type == 7){
                        ok = true;
                        break;
                    }
                    if(TSN.Options_A == null && TSN.Options_B == null & TSN.Options_A_Jump_ID ==0 && TSN.Options_B_Jump_ID ==0){
                        result.add(TSN);
                        NodeID++;
                        continue;
                    }
                    if(TSN.Options_A == null && TSN.Options_B != null){
                        TSN.Options_A = TSN.Options_B;
                    }
                    if(TSN.Options_A != null && TSN.Options_B == null){
                        TSN.Options_B = TSN.Options_A;
                    }
                    if(TSN.Options_A_Jump_ID == 0 && TSN.Options_B_Jump_ID != 0){
                        TSN.Options_B_Jump_ID = TSN.Options_A_Jump_ID;
                    }
                    if(TSN.Options_A_Jump_ID != 0 && TSN.Options_B_Jump_ID == 0){
                        TSN.Options_A_Jump_ID = TSN.Options_B_Jump_ID;
                    }
                    if (TSN.Options_A == null && TSN.Options_B == null){
                        result.add(TSN);
                        NodeID = TSN.Options_A_Jump_ID;
                        continue;
                    }
                    result.add(TSN);
                    break;
                }else{
                    break;
                }
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return result;
    }
    public int GetWaitTime(int NodeID){
        NodeID -= -1;
        int value = 0;
        if(!ST_State){
            return (value);
        }
        if(Story.has(NodeID)){
            JsonNode Tnode;
            try {
                Tnode = mapper.readTree(Story.get(NodeID).toString());
                if(Tnode.has("Options_A_Jump_ID")){
                    value = 500;//默认等待值
                    if(Tnode.has("WaitTime")){
                        value = Tnode.get("WaitTime").asInt();
                    }
                }
                return (value);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        return (value);
    }
    public String[] GetOpinion(int NodeID){
        NodeID -= 1;
        String[] value = new String[4];
        if(!ST_State){
            return (value);
        }
        if(Story.has(NodeID)){
            JsonNode Tnode;
            try {
                Tnode = mapper.readTree(Story.get(NodeID).toString());
                if(Tnode.has("Options_A")){
                    value[0] = Tnode.get("Options_A").asText();
                }else{
                    value[0] = null;
                }
                if(Tnode.has("Options_B")){
                    value[1] = Tnode.get("Options_B").asText();
                }else{
                    value[1] = null;
                }
                if(Tnode.has("Options_A_Jump_ID")){
                    value[2] = String.valueOf(Tnode.get("Options_A_Jump_ID").asInt());
                }else{
                    value[2] = String.valueOf(NodeID + 2);
                }
                if(Tnode.has("Options_B_Jump_ID")){
                    value[3] = String.valueOf(Tnode.get("Options_B_Jump_ID").asInt());
                }else{
                    value[3] = String.valueOf(NodeID + 2);
                }
                if(value[0] == null && value[1] != null){
                    value[0] = value[1];
                }
                if(value[0] != null && value[1] == null){
                    value[1] = value[0];
                }
                if(value[0] == null && value[1] == null){
                    value[0] = "Error";
                    value[1] = "Error";
                }
                return (value);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        return (value);
    }
//    public StoryNode OnlyReadStoryNode(int NodeID){
//        StoryNode TSN = new StoryNode();;
//        TSN.Node_ID = 0;
//        NodeID = NodeID - 1;
//        JsonNode Tnode;
//        if(!ST_State){
//            return (TSN);
//        }
//        if(Story.size() < NodeID){
//            return TSN;
//        }
//        try{
//            if(Story.has(NodeID)){
//                TSN.Node_ID = NodeID+1;
//                Tnode = mapper.readTree(Story.get(NodeID).toString());
//                if(Tnode.has("Node_Content")){
//                    TSN.Node_Content = Tnode.get("Node_Content").toString();
//                }else{
//                    TSN.Node_Content = "";
//                }
//                if(Tnode.has("Options_A")){
//                    TSN.Options_A = Tnode.get("Options_A").toString();
//                }else{
//                    TSN.Options_A = null;
//                }
//                if(Tnode.has("Options_B")){
//                    TSN.Options_B = Tnode.get("Options_B").toString();
//                }else{
//                    TSN.Options_B = null;
//                }
//                if(Tnode.has("Options_A_Jump_ID")){
//                    TSN.Options_A_Jump_ID = Tnode.get("Options_A_Jump_ID").asInt();
//                }else{
//                    TSN.Options_A_Jump_ID = 0;
//                }
//                if(Tnode.has("Options_B_Jump_ID")){
//                    TSN.Options_B_Jump_ID = Tnode.get("Options_B_Jump_ID").asInt();
//                }else{
//                    TSN.Options_B_Jump_ID = 0;
//                }
//                if(Tnode.has("WaitTime")){
//                    TSN.WaitTime = Tnode.get("WaitTime").asInt();
//                }else{
//                    TSN.WaitTime = 0;
//                }
//                if(Tnode.has("Message_Type")){
//                    TSN.Message_Type = Tnode.get("Message_Type").asInt();
//                }else{
//                    TSN.Message_Type = 1;
//                }
//                if(TSN.Message_Type == 7){
//                    return TSN;
//                }
//                if(TSN.Options_A == null && TSN.Options_B == null & TSN.Options_A_Jump_ID ==0 && TSN.Options_B_Jump_ID ==0){
//                    return TSN;
//                }
//                if(TSN.Options_A == null && TSN.Options_B != null){
//                    TSN.Options_A = TSN.Options_B;
//                }
//                if(TSN.Options_A != null && TSN.Options_B == null){
//                    TSN.Options_B = TSN.Options_A;
//                }
//                if(TSN.Options_A_Jump_ID == 0 && TSN.Options_B_Jump_ID != 0){
//                    TSN.Options_B_Jump_ID = TSN.Options_A_Jump_ID;
//                }
//                if(TSN.Options_A_Jump_ID != 0 && TSN.Options_B_Jump_ID == 0){
//                    TSN.Options_A_Jump_ID = TSN.Options_B_Jump_ID;
//                }
//                if (TSN.Options_A == null && TSN.Options_B == null){
//                    return TSN;
//                }
//                return TSN;
//            }else{
//                return TSN;
//            }
//        } catch (JsonProcessingException e) {
//            e.printStackTrace();
//        }
//        return TSN;
//    }
    private void AddMessage(String Content){//System 报错用 不存储
        if(CB_State){
            try {
                mNotifyCallBack.Web_Add_ChatMessage(Shard.CreateMessageString(6,Content, Long.valueOf(0)));
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }
}
