package com.bxv.dline;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE IF NOT EXISTS \"Item\" (\n" +
                "  \"ID\" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,\n" +
                "  \"Key\" String NOT NULL,\n" +
                "  \"Value\" String,\n" +
                "  CONSTRAINT \"Key_repeat\" UNIQUE (\"Key\" ASC)\n" +
                ");";
        db.execSQL(sql);
        sql = "CREATE INDEX IF NOT EXISTS \"list\"\n" +
                "ON \"Item\" (\n" +
                "  \"ID\" ASC,\n" +
                "  \"Key\" ASC\n" +
                ");";
        db.execSQL(sql);
        sql = "CREATE TABLE \"TempItem\" (\n" +
                "  \"ID\" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,\n" +
                "  \"Key\" String NOT NULL,\n" +
                "  \"Value\" String NOT NULL,\n" +
                "  CONSTRAINT \"Key_repeat\" UNIQUE (\"Key\")\n" +
                ");";
        db.execSQL(sql);
        sql = "CREATE INDEX \"TempItem_list\"\n" +
                "ON \"TempItem\" (\n" +
                "  \"ID\" ASC,\n" +
                "  \"Key\" ASC\n" +
                ");";
        db.execSQL(sql);
        sql = "CREATE TABLE \"ChatHistory\" (\n" +
                "  \"ID\" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,\n" +
                "  \"Node_ID\" INTEGER,\n" +
                "  \"Content\" String,\n" +
                "  \"Send_Date\" INTEGER,\n" +
                "  \"Message_Type\" INTEGER,\n" +
                "  \"Class\" LONG\n" +
                ");";
        db.execSQL(sql);
        sql = "CREATE INDEX \"ChatHistory_list\"\n" +
                "ON \"ChatHistory\" (\n" +
                "  \"ID\" ASC,\n" +
                "  \"Node_ID\" ASC,\n" +
                "  \"Send_Date\" ASC\n" +
                ");";
        db.execSQL(sql);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}
