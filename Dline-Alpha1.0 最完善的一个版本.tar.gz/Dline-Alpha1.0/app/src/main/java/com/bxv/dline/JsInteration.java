package com.bxv.dline;

import android.os.RemoteException;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

public class  JsInteration {
    WebView mWebView;
    SQLite mSQLite;
    IAidlInterface_Service mIAidlInterface_Service;
    public void Initialization_WebView(WebView TWebView){
        mWebView = TWebView;
    }
    public void Initialization_MessageDealService(IAidlInterface_Service TMessageDealService){
        mIAidlInterface_Service = TMessageDealService;
    }
    public void Initialization_SQLite(SQLite sSQLite){
        mSQLite = sSQLite;
    }
    @JavascriptInterface
    public void OpinionA_Choose(){
        try {
            mIAidlInterface_Service.OpinionA_Choose();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }
    @JavascriptInterface
    public void OpinionB_Choose(){
        try {
            mIAidlInterface_Service.OpinionB_Choose();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }
    @JavascriptInterface
    public void ReSetStory(String LStory){
        String LUserReStory = mSQLite.CreateTempItemName();
        mSQLite.SetTempItem(LUserReStory,LStory);
        try {
            mIAidlInterface_Service.ReSetStory_BySQLite(LUserReStory);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }
    @JavascriptInterface
    public void TempItem_SetItem(String Key,String Value){
        mSQLite.SetTempItem(Key,Value);
    }
    @JavascriptInterface
    public String TempItem_GetItem(String Key){
        return (mSQLite.GetTempItem(Key));
    }
    @JavascriptInterface
    public void ChangeBtnState(int type,boolean State){
        //type
        //1 = MessageState
        //2 = MessageMode
        switch (type){
            case 1:
                mSQLite.SetItem("btn_MessageState", String.valueOf(State));
            break;
            case 2:
                mSQLite.SetItem("btn_MessageMode", String.valueOf(State));//这玩意没啥用,摆设
            break;
        }
        try {
            mIAidlInterface_Service.Update_MessageNoticeMode();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }
}
