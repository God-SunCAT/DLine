package com.bxv.dline;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

public class BootBroadCastReceiver  extends BroadcastReceiver {
    public BootBroadCastReceiver() {
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onReceive(Context context, Intent intent) {
//        if(intent.getAction().equals(Intent.ACTION_USER_PRESENT)){
//            Log.d("BXV","AZ");
//            Intent nIntent=new Intent();
//            nIntent.setClass(context, MessageDealService.class);
//            context.startForegroundService(intent);
//        }
        if(intent.getAction().equals("restartService")){
            Intent nIntent=new Intent();
            nIntent.setClass(context, MessageDealService.class);
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                context.startForegroundService(intent);
//            } else {
//                context.startService(intent);
//            }
            context.startForegroundService(intent);
        }
    }

}
